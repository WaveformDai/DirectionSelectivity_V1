% this funtion aims to show results in S2 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S2_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some paramters
depthBoundary = [ ...
    0, ...
    0.3500, ...
    0.5800, ...
    0.7600, ....
    1.0000, ...
    ];

allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

layerID_output = [1 3];
layerID_input = [2 4];

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S2 Fig';
figureHandle(figureCount) = figure(figureCount);

%% show results for S2A Fig
% get data
[currResp_MUA_interp,~,~] = xlsread(fullFileName,'S2A Fig MUA');
[currResp_LFP_interp,~,~] = xlsread(fullFileName,'S2A Fig LFP');
[currCSD_interp,~,~] = xlsread(fullFileName,'S2A Fig CSD');

% pre-define some paramters
allRelativeDepth_interp = linspace(-0.5,1.5,101);
timePoint = -50:2:250;

defaultColorMap = parula(256);

% range for showing results
currTimeMin = timePoint(1);
% currTimeMax = timePoint(end);
currTimeMax = 150;

currDepthMin = -0.1;
currDepthMax = 1.1;

currTimeTickPos = [-50 0 100 200];
currTimeLabel = [-50 0 100 200];

currDepthTickPos = [0 1];
currDepthLabel = [0 1];

validDepthIndex = find(allRelativeDepth_interp > 0 & allRelativeDepth_interp <= 1);

% show interpolated MUA
tempData = currResp_MUA_interp(validDepthIndex,:);
currMax = max(abs(tempData(:)));
currMin = -currMax;

subplot(2,3,1)
imagesc(timePoint,allRelativeDepth_interp,currResp_MUA_interp,[currMin currMax])
currXLim = get(gca,'XLim');
currYLim = get(gca,'YLim');
hold on;
plot([0 0],currYLim,'w-.','LineWidth',lineWidth)

% show boundary for each layer
for boundaryIndex = 1:length(depthBoundary)
    currDepthBoundary = depthBoundary(boundaryIndex);
    
    plot([currTimeMin currTimeMax],currDepthBoundary+[0 0],'r-.','LineWidth',lineWidth)
end

set(gca,'XTick',currTimeTickPos)
set(gca,'XTickLabel',currTimeLabel)
set(gca,'YTick',currDepthTickPos)
set(gca,'YTickLabel',currDepthLabel)
xlim([currTimeMin currTimeMax])
ylim([currDepthMin currDepthMax])
xlabel('Time(ms)','FontSize',fontSize)
ylabel('Relative Depth','FontSize',fontSize)
title('MUA','FontSize',fontSize)

colormap(defaultColorMap)
colorbar;
set(gca,'FontSize',fontSize)

% show interpolated LFP
tempData = currResp_LFP_interp(validDepthIndex,:);
currMax = max(abs(tempData(:)));
currMin = -currMax;

subplot(2,3,2)
imagesc(timePoint,allRelativeDepth_interp,currResp_LFP_interp,[currMin currMax])
currXLim = get(gca,'XLim');
currYLim = get(gca,'YLim');
hold on;
plot([0 0],currYLim,'w-.','LineWidth',lineWidth)

% show boundary for each layer
for boundaryIndex = 1:length(depthBoundary)
    currDepthBoundary = depthBoundary(boundaryIndex);
    
    plot([currTimeMin currTimeMax],currDepthBoundary+[0 0],'r-.','LineWidth',lineWidth)
end

set(gca,'XTick',currTimeTickPos)
set(gca,'XTickLabel',currTimeLabel)
set(gca,'YTick',currDepthTickPos)
set(gca,'YTickLabel',currDepthLabel)
xlim([currTimeMin currTimeMax])
ylim([currDepthMin currDepthMax])
xlabel('Time(ms)','FontSize',fontSize)
ylabel('Relative Depth','FontSize',fontSize)
title('LFP','FontSize',fontSize)

colormap(defaultColorMap)
colorbar;
set(gca,'FontSize',fontSize)

% show interpolated CSD
tempData = currCSD_interp(validDepthIndex,:);
currMax = max(abs(tempData(:)));
currMin = -currMax;
% currMax = max(tempData(:));
% currMin = min(tempData(:));

subplot(2,3,3)
imagesc(timePoint,allRelativeDepth_interp,currCSD_interp,[currMin currMax])
currXLim = get(gca,'XLim');
currYLim = get(gca,'YLim');
hold on;
plot([0 0],currYLim,'w-.','LineWidth',lineWidth)

% show boundary for each layer
for boundaryIndex = 1:length(depthBoundary)
    currDepthBoundary = depthBoundary(boundaryIndex);
    
    plot([currTimeMin currTimeMax],currDepthBoundary+[0 0],'r-.','LineWidth',lineWidth)
end

set(gca,'XTick',currTimeTickPos)
set(gca,'XTickLabel',currTimeLabel)
set(gca,'YTick',currDepthTickPos)
set(gca,'YTickLabel',currDepthLabel)
xlim([currTimeMin currTimeMax])
ylim([currDepthMin currDepthMax])
xlabel('Time(ms)','FontSize',fontSize)
ylabel('Relative Depth','FontSize',fontSize)
title('CSD','FontSize',fontSize)

colormap(defaultColorMap)
colorbar;
set(gca,'FontSize',fontSize)

%% show results for S2B Fig
% get data
[allElecNum_eachLayer,~,~] = xlsread(fullFileName,'S2B Fig');

% parameters for showing histogram
binNum = 10;
minElecNum_eachLayer = 0.5;
maxElecNum_eachLayer = max(allElecNum_eachLayer(:))+0.5;
currEdge_elecNum = linspace(minElecNum_eachLayer,maxElecNum_eachLayer,binNum);

% edge to be shown
currEdgeDiff_elecNum = (currEdge_elecNum(2)-currEdge_elecNum(1))/2;
currShownEdge_elecNum = currEdge_elecNum+currEdgeDiff_elecNum;
currShownEdge_elecNum = currShownEdge_elecNum(1:(end-1));

probeElecIndex = 1:25;
mmfElecIndex = 26;

% get histogram
allMedian_elecNum_probe = zeros(1,4);
allHist_elecNum_probe = zeros(binNum-1,4);

allHist_elecNum_mmf = zeros(binNum-1,4);
for layerIndex = 1:4
    currElecNum_eachLayer = allElecNum_eachLayer(probeElecIndex,layerIndex); % expNum*1
    currMedian_elecNum_probe = median(currElecNum_eachLayer);
    currHist_elecNum_probe = histcounts(currElecNum_eachLayer,currEdge_elecNum);
    
    currElecNum_eachLayer = allElecNum_eachLayer(mmfElecIndex,layerIndex); % expNum*1
    currHist_elecNum_mmf = histcounts(currElecNum_eachLayer,currEdge_elecNum);
    
    allMedian_elecNum_probe(layerIndex) = currMedian_elecNum_probe;
    allHist_elecNum_probe(:,layerIndex) = currHist_elecNum_probe;
    
    allHist_elecNum_mmf(:,layerIndex) = currHist_elecNum_mmf;
end

% get range for showing results
currXMin = min([currShownEdge_elecNum(:)]);
currXMax = max([currShownEdge_elecNum(:)])+1;
currXRange = currXMax-currXMin;

textXPos = currXMin+currXRange*0.1;

figRowNum = 4;
figColNum = 3;

% show histogram for each layer
for layerIndex = 1:4
    currMedian_elecNum_probe = allMedian_elecNum_probe(layerIndex);
    currHist_elecNum_probe = allHist_elecNum_probe(:,layerIndex);
    
    currHist_elecNum_mmf = allHist_elecNum_mmf(:,layerIndex);
    
    currLayerLabel = ['L',allLayerLabel{layerIndex}];
    
    currYMin = 0;
    currYMax = max([currHist_elecNum_probe(:)+currHist_elecNum_mmf(:)]);
    currYRange = currYMax-currYMin;
    currYMax = currYMin+currYRange*1.15;
    
    textYPos = currYMin+currYRange*0.8;
    markerYPos = currYMin+currYRange*1.1;
    
    if sum(layerID_output == layerIndex) > 0 % output layer
        currColor = 'b';
    else % input layer
        currColor = 'r';
    end
    
    figRowIndex = 4-mod(layerIndex,2);
    figColIndex = ceil(layerIndex./2);
    subFigIndex = (figRowIndex-1)*figColNum+figColIndex;
    %     subFigIndex = (layerIndex-1)*figColNum+3;
    subplot(figRowNum,figColNum,subFigIndex)
    hold off;
    currBarHandle = bar(currShownEdge_elecNum,[currHist_elecNum_probe(:),currHist_elecNum_mmf(:)],'stacked');
    set(currBarHandle(1),'EdgeColor','none','FaceColor',currColor)
    set(currBarHandle(2),'EdgeColor','none','FaceColor','k')
    hold on;
    plot(currMedian_elecNum_probe,markerYPos,'v','MarkerEdgeColor',currColor,'MarkerFaceColor',currColor)
    text(textXPos,textYPos,currLayerLabel,'Color',currColor,'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    if figRowIndex == figRowNum
        xlabel('#Elec','FontSize',fontSize)
    end
    ylabel('#Count','FontSize',fontSize)
    set(gca,'fontsize',fontSize)
    if layerIndex == 1
        currLegendLabel = legend([currBarHandle(1),currBarHandle(2)],'UProbe','Probe64D','Location','northeast');
        set(currLegendLabel,'fontsize',fontSize)
    end
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);