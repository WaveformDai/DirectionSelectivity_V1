% this funtion aims to show results in Fig 7 for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig7_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

patchSaturation = 0.33; % saturation for patch of shaded errorbar

%% show results for upper half of Fig 7
% get data
[allData_nullDir_blank,~,~] = xlsread(fullFileName,'Fig 7A Upper');
[allData_prefDir_blank,~,~] = xlsread(fullFileName,'Fig 7B Upper');
[allData_prefDir_nullDir,~,~] = xlsread(fullFileName,'Fig 7C Upper');

% pre-define some parameters
currDepth_interp = linspace(0,1,51);
interpDepthNum = length(currDepth_interp);

depthBoundary = [ ...
    0, ...
    0.3500, ...
    0.5800, ...
    0.7600, ....
    1.0000, ...
    ];

allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

shownPairName = { ...
    'nullDir-blank', ...
    'prefDir-blank', ...
    'prefDir-nullDir', ...
    };

% get range for showing results
currMax = max(abs([allData_nullDir_blank(:);allData_prefDir_blank(:);allData_prefDir_nullDir(:)])); % use the same colorar for all figurs.
if currMax == 0 || isnan(currMax)
    currMax = 1e-6;
end
currMin = -currMax;

% parameters for showing results
figRowNum = 3;
figColNum = 6;

fontSize = 15;
lineWidth = 1;

% get position for showing results
leftGap = 0.06; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.06; % gap from bottom edge
topGap = 0.03; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.08; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% position for showing layer info
currTickPos = (depthBoundary(1:4)+depthBoundary(2:5))/2;
currTickLabel = allLayerLabel(1:4);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig7_upper';
figureHandle(figureCount) = figure(figureCount);

for pairIndex = 1:length(shownPairName)
    currShownPairName = shownPairName{pairIndex};
    
    % get data
    switch currShownPairName
        case 'nullDir-blank'
            currShownData = allData_nullDir_blank;
        case 'prefDir-blank'
            currShownData = allData_prefDir_blank;
        case 'prefDir-nullDir'
            currShownData = allData_prefDir_nullDir;
    end
    
    % show interpolated data
    figRowIndex = 1;
    figColIndex = pairIndex*2-1;
    currBotPos = botPos(figRowIndex);
    currLeftPos = leftPos(figColIndex);
    subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight])
    imagesc(currDepth_interp,currDepth_interp,currShownData,[currMin currMax])
    currXLim = get(gca,'XLim');
    currYLim = get(gca,'YLim');
    hold on;
    for boundaryIndex = 1:length(depthBoundary)
        currDepthBoundary = depthBoundary(boundaryIndex);
        if boundaryIndex == 1
            continue;
        end
        currColor = 'w';
        plot(currXLim(1)+currDepthBoundary+[0 0],currYLim,'-.','color',currColor,'LineWidth',lineWidth)
        plot(currXLim,currYLim(1)+currDepthBoundary+[0 0],'-.','color',currColor,'LineWidth',lineWidth)
    end
    axis image;
    xlim([0 1])
    ylim([0 1])
    colormap(parula);
    currCBHandle = colorbar;
    set(currCBHandle,'Ticks',[currMin,currMax], ...
        'TickLabels',{sprintf('%.2f',currMin),sprintf('%.2f',currMax)})
    set(gca,'XTick',currTickPos,'XTickLabel',currTickLabel)
    set(gca,'YTick',currTickPos,'YTickLabel',currTickLabel)
    xlabel('from','FontSize',fontSize)
    ylabel('to','FontSize',fontSize)
    title(currShownPairName,'FontSize',fontSize)
    
    set(gca,'FontSize',fontSize)
end

%% show results for lower half of Fig 7
% get data
[allData_nullDir_blank,~,~] = xlsread(fullFileName,'Fig 7A Lower');
[allData_prefDir_blank,~,~] = xlsread(fullFileName,'Fig 7B Lower');
[allData_prefDir_nullDir,~,~] = xlsread(fullFileName,'Fig 7C Lower');

% parameters for showing results
figRowNum = 3;
figColNum = 6;

% get position for showing results
leftGap = 0.06; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.06; % gap from bottom edge
topGap = 0.03; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.08; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% position for showing layer info
currTickPos = (depthBoundary(1:4)+depthBoundary(2:5))/2;
currTickLabel = allLayerLabel(1:4);

% create colormap for showing p-val
currMap_pval = [ ...
    0 0 0; ... % p <= 0.001
    0.25 0.25 0.25; ... % p <= 0.01
    0.5 0.5 0.5; ... % p <= 0.05
    1 1 1; ... % p > 0.05
    ];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig7_lower';
figureHandle(figureCount) = figure(figureCount);

for pairIndex = 1:length(shownPairName)
    currShownPairName = shownPairName{pairIndex};
    
    % get data
    switch currShownPairName
        case 'nullDir-blank'
            currShownData = allData_nullDir_blank;
        case 'prefDir-blank'
            currShownData = allData_prefDir_blank;
        case 'prefDir-nullDir'
            currShownData = allData_prefDir_nullDir;
    end
    
    % reconstrucut data
    currPVal_interp = 4*ones(interpDepthNum,interpDepthNum);
    
    for sourceLayerIndex = 1:(length(allLayerLabel)-1)
        % get index for depth
        currDepthBoundary_low = depthBoundary(sourceLayerIndex);
        currDepthBoundary_high = depthBoundary(sourceLayerIndex+1);
        %             currIndex_source = find(currDepth_interp > currDepthBoundary_low & currDepth_interp <= currDepthBoundary_high);
        currIndex_source = find(currDepth_interp >= currDepthBoundary_low & currDepth_interp < currDepthBoundary_high);
        
        for targetLayerIndex = 1:(length(allLayerLabel)-1)
            % get index for depth
            currDepthBoundary_low = depthBoundary(targetLayerIndex);
            currDepthBoundary_high = depthBoundary(targetLayerIndex+1);
            %                 currIndex_target = find(currDepth_interp > currDepthBoundary_low & currDepth_interp <= currDepthBoundary_high);
            currIndex_target = find(currDepth_interp >= currDepthBoundary_low & currDepth_interp < currDepthBoundary_high);
            
            % get p-val
            tempPVal = currShownData(targetLayerIndex,sourceLayerIndex);
            if tempPVal <= 0.001
                tempPVal = 1;
            elseif tempPVal <= 0.01
                tempPVal = 2;
            elseif tempPVal <= 0.05
                tempPVal = 3;
            else
                tempPVal = 4;
            end
            
            currPVal_interp(currIndex_target,currIndex_source) = tempPVal;
        end
    end
    
    % get range for showing results
    currMin = 1;
    currMax = 4;
    
    % show interpolated data
    figRowIndex = 2;
    figColIndex = pairIndex*2-1;
    currBotPos = botPos(figRowIndex);
    currLeftPos = leftPos(figColIndex);
    subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight])
    imagesc(currDepth_interp,currDepth_interp,currPVal_interp,[currMin currMax])
    currXLim = get(gca,'XLim');
    currYLim = get(gca,'YLim');
    hold on;
    for boundaryIndex = 1:length(depthBoundary)
        currDepthBoundary = depthBoundary(boundaryIndex);
        if boundaryIndex == 1
            continue;
        end
        currColor = 'b';
        plot(currXLim(1)+currDepthBoundary+[0 0],currYLim,'-.','color',currColor,'LineWidth',lineWidth)
        plot(currXLim,currYLim(1)+currDepthBoundary+[0 0],'-.','color',currColor,'LineWidth',lineWidth)
    end
    axis image;
    xlim([0 1])
    ylim([0 1])
    colormap(currMap_pval);
    set(gca,'XTick',currTickPos,'XTickLabel',currTickLabel)
    set(gca,'YTick',currTickPos,'YTickLabel',currTickLabel)
    xlabel('from','FontSize',fontSize)
    ylabel('to','FontSize',fontSize)
    
    title(currShownPairName,'FontSize',fontSize)
    
    set(gca,'FontSize',fontSize)
    
    % create color-bar
    currCBHandle = colorbar;
    
    % change label
    set(currCBHandle,'Ticks',1.375+0.75*(0:3), ...
        'TickLabels',{'<0.001','<0.01','<0.05','>0.05'})
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);