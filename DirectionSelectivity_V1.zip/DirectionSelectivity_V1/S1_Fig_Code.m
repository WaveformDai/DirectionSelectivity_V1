% this funtion aims to show results in S1 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S1_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

patchSaturation = 0.33; % saturation for patch of shaded errorbar

% pre-define some parameters
layerID_output = [1 3];
layerID_input = [2 4];

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S1 Fig';
figureHandle(figureCount) = figure(figureCount);

%% show results for S1A Fig
% get data
[allData,~,~] = xlsread(fullFileName,'S1A Fig');

allDiff_rfCenter_median = allData(:,1);
allDiff_prefOri_median = allData(:,2);
allShownExpIndex_dg = allData(1:3,3);

% get range for showing results
currXMin = 0;
currXMax = max(allDiff_rfCenter_median);
currXMax = currXMax*(1+0.05*sign(currXMax));

currYMin = 0;
currYMax = 1.05;

subplot(1,2,1)
plot(allDiff_rfCenter_median,allDiff_prefOri_median,'o', ...
    'MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',markerSize/2)
hold on;
plot(allDiff_rfCenter_median(allShownExpIndex_dg),allDiff_prefOri_median(allShownExpIndex_dg),'o', ...
    'MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',markerSize/2)
xlim([currXMin currXMax])
ylim([currYMin currYMax])
xlabel('RF Center Dispersion','FontSize',fontSize)
ylabel('Preferred Orientation Consistency','FontSize',fontSize)

%% show results for S1B Fig
% parameters for showing results
figRowNum = 3;
figColNum = 4;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.06; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

for expIndex = 1:3
    currSheetName_contour = ['S1B Fig Contour Exp',num2str(expIndex)];
    currSheetName_oriTuning = ['S1B Fig OriTuning Exp',num2str(expIndex)];
    
    %%% show RF contour
    % get data
    [allData,~,~] = xlsread(fullFileName,currSheetName_contour);
    
    % get data
    currValidElecNum_spn = size(allData,2)./3;
    currContour_xx = allData(:,1:currValidElecNum_spn);
    currContour_yy = allData(:,currValidElecNum_spn+[1:currValidElecNum_spn]);
    currLayerID_spn = allData(1,currValidElecNum_spn*2+[1:currValidElecNum_spn]);
    
    if currValidElecNum_spn > 0
        % get range for showing results
        minContour_xx = min(currContour_xx(:));
        maxContour_xx = max(currContour_xx(:));
        currRange_xx = maxContour_xx-minContour_xx;
        minContour_xx = minContour_xx-0.05*currRange_xx;
        maxContour_xx = maxContour_xx+0.05*currRange_xx;
        
        minContour_yy = min(currContour_yy(:));
        maxContour_yy = max(currContour_yy(:));
        currRange_yy = maxContour_yy-minContour_yy;
        minContour_yy = minContour_yy-0.05*currRange_yy;
        maxContour_yy = maxContour_yy+0.05*currRange_yy;
        
        % get color for showing results
        allColor = repmat(linspace(0.5,0,currValidElecNum_spn)',1,3);
        
        % show results
        figRowIndex = expIndex;
        figColIndex = 3;
        currBotPos = botPos(figRowIndex)+0.03;
        currLeftPos = leftPos(figColIndex);
        subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight])
        hold on;
        for elecIndex = 1:currValidElecNum_spn
            % get data
            tempContour_xx = currContour_xx(:,elecIndex);
            tempContour_y = currContour_yy(:,elecIndex);
            tempLayerID_spn = currLayerID_spn(elecIndex);
            
            % get color for data to be shown
            if sum(layerID_input == tempLayerID_spn) > 0
                currColor = 'r';
            else
                currColor = 'b';
            end
            
            currLineWidth = 1;
            currLineType = '-';
            
            plot(tempContour_xx,tempContour_y,currLineType, ...
                'color',currColor,'LineWidth',currLineWidth)
        end
        
        % modify label
        axis equal;
        xlim([minContour_xx maxContour_xx])
        ylim([minContour_yy maxContour_yy])
        if figRowIndex == figRowNum
            xlabel('Azimuth','FontSize',fontSize)
        end
        ylabel('Elevation','FontSize',fontSize)
        set(gca,'FontSize',fontSize)
        box off;
    end
    
    %%% show orientation tuning
    % get data
    [allData,~,~] = xlsread(fullFileName,currSheetName_oriTuning);
    
    % get data
    currValidElecNum_dg = (size(allData,2)-1)./2;
    
    fitOri = allData(:,1);
    currOriTuning = allData(:,1+[1:currValidElecNum_dg]);
    currLayerID_dg = allData(1,currValidElecNum_dg+1+[1:currValidElecNum_dg]);
    
    if currValidElecNum_dg > 0
        % get range for showing results
        currMin_xx = fitOri(1);
        currMax_xx = fitOri(end);
        
        currMin_yy = 0;
        currMax_yy = 1.05;
        
        % get color for showing results
        allColor = repmat(linspace(0.5,0,currValidElecNum_dg)',1,3);
        
        % show results
        figColIndex = 4;
        currLeftPos = leftPos(figColIndex);
        subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight])
        hold on;
        for elecIndex = 1:currValidElecNum_dg
            % get data
            tempOriTuning = currOriTuning(:,elecIndex);
            tempLayerID_dg = currLayerID_dg(elecIndex);
            
            % normalie data
            %                 tempOriTuning = (tempOriTuning-min(tempOriTuning))./(max(tempOriTuning)-min(tempOriTuning));
            tempOriTuning = tempOriTuning./max(tempOriTuning);
            
            % get color for data to be shown
            if sum(layerID_input == tempLayerID_dg) > 0
                currColor = 'r';
            else
                currColor = 'b';
            end
            
            currLineWidth = 1;
            currLineType = '-';
            
            plot(fitOri,tempOriTuning,currLineType, ...
                'color',currColor,'LineWidth',currLineWidth)
        end
        
        % modify label
        xlim([currMin_xx currMax_xx])
        ylim([currMin_yy currMax_yy])
        if figRowIndex == figRowNum
            xlabel('Orientation','FontSize',fontSize)
        end
        ylabel('Normalized Response','FontSize',fontSize)
        
        set(gca,'FontSize',fontSize)
        box off;
    end
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);