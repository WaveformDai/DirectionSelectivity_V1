% this funtion aims to show results in Fig 5 for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig5_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some paramter
fitR2Thre = 0.8;

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% get position for showing results
figRowNum = 2;
figColNum = 3;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.05; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.11; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.16; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig5';
figureHandle(figureCount) = figure(figureCount);

%% show results for Fig 5E
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 5E');

% allocate data
allAdjR2_untuned = allData(:,1);
allAdjR2_tuned = allData(:,2);

% get statistics
currPVal_pair_signrank = signrank(allAdjR2_untuned,allAdjR2_tuned);

% get range for shown result
currMin = 0;
currMax = 1;
currRange = currMax-currMin;

textXPos = currMin+currRange*0;
textYPos_coef = currMin+currRange*1.15;
textYPos_signrank = currMin+currRange*1.05;

textString_coef = sprintf('N=%d', ...
    length(allAdjR2_untuned));
textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);

currXLabel = 'adjR2: Untuned Gain';
currYLabel = 'adjR2: Tuned Gain';

% show comparison
figRowIndex = 2;
figColIndex = 1;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex)+0.05;
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
plot(allAdjR2_untuned,allAdjR2_tuned,'o', ...
    'MarkerEdgeColor','k','MarkerFaceColor','k')
hold on;
plot([currMin currMax],[currMin currMax],'k-.')
text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
plot(fitR2Thre+[0 0],[currMin currMax],'k-.')
plot([currMin currMax],fitR2Thre+[0 0],'k-.')
xlim([currMin currMax])
ylim([currMin currMax])
xlabel(currXLabel,'FontSize',fontSize)
ylabel(currYLabel,'FontSize',fontSize)
%                 title(shownDataLabel,'FontSize',fontSize)
axis square;

set(gca,'FontSize',fontSize)
box off;

%% show results for Fig 5BCF
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 5');

% allocate data
allDSI_untuned = allData(:,1);
allDSI_tuned = allData(:,2);
allDSI_output = allData(:,3);
allDSI_input = allData(:,4);

% pre-define some paramters
shownReferenceName = { ...
    'Input Layers', ...
    'Output Layers', ...
    'Output Layers', ...
    };
shownTargetName = { ...
    'Untuned Gain', ...
    'Untuned Gain', ...
    'tuned', ...
    };

shownReferenceName_brief = { ...
    'input', ...
    'output', ...
    'output', ...
    };
shownTargetName_brief = { ...
    'untuned', ...
    'untuned', ...
    'tuned', ...
    };

for pairIndex = 1:length(shownReferenceName)
    currShownReferenceName = shownReferenceName{pairIndex};
    currShownTargetName = shownTargetName{pairIndex};
    
    currShownReferenceName_brief = shownReferenceName_brief{pairIndex};
    currShownTargetName_brief = shownTargetName_brief{pairIndex};
    
    % get data to be shown
    cmd = ['currData_reference = allDSI_',currShownReferenceName_brief,';'];
    eval(cmd);
    
    cmd = ['currData_target = allDSI_',currShownTargetName_brief,';'];
    eval(cmd);
    
    % get statistics
    currPVal_pair_signrank = signrank(currData_reference,currData_target);
    
    % get range for shown result
    currMin = 0;
    currMax = 1;
    currRange = currMax-currMin;
    
    textXPos = currMin+currRange*0;
    textYPos_coef = currMin+currRange*1.15;
    textYPos_signrank = currMin+currRange*1.05;
    
    textString_coef = sprintf('N=%d', ...
        length(currData_reference));
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    currXLabel = ['DSI:',currShownReferenceName];
    currYLabel = ['DSI:',currShownTargetName];
    
    % show comparison
    figRowIndex = 1;
    figColIndex = pairIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    plot(currData_reference,currData_target,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot([currMin currMax],[currMin currMax],'k-.')
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currMin currMax])
    ylim([currMin currMax])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% show results for Fig 5DG
% get position for showing results
figRowNum = 2;
figColNum = 3;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.05; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.11; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.16; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get range for histogram
currMin_ratio = 0; % min improvement: 0
currMax_ratio= 1; % max improvement: 0

% get bin for histogram
binNum = 9;
currEdge_ratio = linspace(currMin_ratio,currMax_ratio,binNum);

currEdgeDiff_ratio = (currEdge_ratio(2)-currEdge_ratio(1))/2;
currShownEdge_ratio = currEdge_ratio+currEdgeDiff_ratio;
currShownEdge_ratio = currShownEdge_ratio(1:(end-1));

% get range for showing results
currXMin = currEdge_ratio(1)-currEdgeDiff_ratio;
currXMax = currEdge_ratio(end)+currEdgeDiff_ratio*2;
currXRange = currXMax-currXMin;

deltaDSI_componentName = { ... % contribution of each component to the improvement in DSI
    'Nonlinearity', ... % nonlinearity
    'Tuned Gain', ... % tuned gain
    };

% show distribution
for deltaDSIIndex = 1:length(deltaDSI_componentName)
    currDeltaDSI_componentName = deltaDSI_componentName{deltaDSIIndex};
    
    % get data
    currData_reference = allDSI_output-allDSI_input;
    switch currDeltaDSI_componentName
        case 'Nonlinearity'
            currData_target = allDSI_untuned-allDSI_input;
        case 'Tuned Gain'
            currData_target = allDSI_tuned-allDSI_untuned;
    end
    
    % get proportion
    currShownRatio = currData_target./currData_reference;
    currShownRatio(currShownRatio < 0) = 0;
    currShownRatio(currShownRatio > 1) = 1;
    
    % get histogram
    currHist_ratio = histcounts(currShownRatio,currEdge_ratio);
    currHist_ratio = currHist_ratio./sum(currHist_ratio);
    
    % get cumulative distribution
    currCumDistribution_ratio = cumsum(currHist_ratio);
    
    % get statistics
    currMedian_ratio = median(currShownRatio);
    currMean_ratio = mean(currShownRatio);
    currStd_ratio = std(currShownRatio);
    currSte_ratio = currStd_ratio./sqrt(length(currShownRatio));
    
    % get range for showing results
    currHistMin = 0;
    currHistMax = max(currHist_ratio(:));
    currHistRange = currHistMax-currHistMin;
    
    errorbarYPos = currHistMin+currHistRange*1.05;
    
    currYMin = currHistMin;
    currYMax = currHistMin+currHistRange*1.1;
    currYRange = currYMax-currYMin;
    
    currXLabel_ratio = ['Contribution(',currDeltaDSI_componentName,')'];
    
    textXPos = currXMin+currXRange*0.8;
    textYPos_exp = currYMin+currYRange*0.95;
    textYPos_ranksum = currYMin+currYRange*0.85;
    textYPos_signtest = currYMin+currYRange*0.75;
    
    % show histogram
    figRowIndex = 2;
    figColIndex = deltaDSIIndex+1;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex)+0.05;
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    currBarHandle = bar(currShownEdge_ratio,currHist_ratio(:));
    set(currBarHandle,'EdgeColor','k','FaceColor','k')
    hold on;
    errorbar(currMedian_ratio,errorbarYPos,currSte_ratio, ...
        '-','horizontal','Color','k')
    plot(currMedian_ratio,errorbarYPos,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    text(textXPos,textYPos_exp,sprintf('N=%d',length(currShownRatio)),'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel(currXLabel_ratio,'FontSize',fontSize)
    ylabel('Proportion','FontSize',fontSize)
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);