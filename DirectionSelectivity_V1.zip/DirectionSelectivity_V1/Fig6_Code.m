% this funtion aims to show results in Fig 6 for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig6_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

patchSaturation = 0.33; % saturation for patch of shaded errorbar

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig6';
figureHandle(figureCount) = figure(figureCount);

%% show results for Fig 6A
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 6A');

% allocate data
fitDir = allData(:,1);

currShownGain_center = allData(:,2);
currShownGain_ste = allData(:,3);

currGain_blank_center = allData(1,4);
currGain_blank_ste = allData(1,5);

% get position for showing results
figRowNum = 4;
figColNum = 4;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.03; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

figRowNum = 3;
leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get range for showing results
currXMin = fitDir(1);
currXMax = fitDir(end);

currYMin = min([currShownGain_center(:)-currShownGain_ste(:)]);
currYMax = max([currShownGain_center(:)+currShownGain_ste(:)]);
currYMin = currYMin*(1-0.05*sign(currYMin));
currYMax = currYMax*(1+0.05*sign(currYMax));
currYMin = min(currYMin,0);

xxTickPos = 0:50:350;
xxTickLabel = 0:50:350;

% show mean/median dir tuning of gain
figRowIndex = 1;
figColIndex = 1;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
hold on;
curSEHandle = shadedErrorBar([currXMin currXMax],currGain_blank_center+[0 0],currGain_blank_ste+[0 0], ...
    'patchSaturation',patchSaturation);
set(curSEHandle.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle.patch,'FaceColor','k')
set(curSEHandle.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle.edge(2),'Color','none','LineWidth',lineWidth/2)

curSEHandle = shadedErrorBar(fitDir,currShownGain_center,currShownGain_ste, ...
    'patchSaturation',patchSaturation);
set(curSEHandle.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle.patch,'FaceColor','k')
set(curSEHandle.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle.edge(2),'Color','none','LineWidth',lineWidth/2)

xlabel('Direction','FontSize',fontSize)
ylabel('Gain','FontSize',fontSize)
xlim([currXMin currXMax])
ylim([currYMin currYMax])
set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)

set(gca,'FontSize',fontSize)
box off;

%% show results for Fig 6B
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 6B');

% allocate data
currData_reference = allData(:,1);
currData_target = allData(:,2);

% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get statistics
[currCoef_pair_coef,currPVal_pair_coef] = corr(currData_reference,currData_target,'type','Spearman');

% get range for shown result
currMin_reference = min([currData_reference(:)]);
currMax_reference = max([currData_reference(:)]);
currMin_reference = currMin_reference*(1-0.05*sign(currMin_reference));
currMax_reference = currMax_reference*(1+0.05*sign(currMax_reference));
currMin_reference = min(currMin_reference,0);
currRange_reference = currMax_reference-currMin_reference;

currMin_target = min([currData_target(:)]);
currMax_target = max([currData_target(:)]);
currMin_target = currMin_target*(1-0.05*sign(currMin_target));
currMax_target = currMax_target*(1+0.05*sign(currMax_target));
currMin_target = min(currMin_target,0);
currRange_target = currMax_target-currMin_target;

% do linear fitting
fitXX_data = [currMin_reference,currMax_reference];

currFitCoef = polyfit(currData_reference,currData_target,1);
currFitYY = currFitCoef*[fitXX_data;1,1];

textXPos = currMin_reference+currRange_reference*0;
textYPos_coef = currMin_target+currRange_target*1.15;

textString_coef = sprintf('N=%d,r=%.2g,p=%.3g', ...
    length(currData_reference),currCoef_pair_coef,currPVal_pair_coef);

currXLabel = 'DSI: Output Layers';
currYLabel = 'DSI: Gain';

% show comparison
figRowIndex = 1;
figColIndex = 3;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
plot(currData_reference,currData_target,'o', ...
    'MarkerEdgeColor','k','MarkerFaceColor','k')
hold on;
plot(fitXX_data,currFitYY,'k-','LineWidth',lineWidth)
text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
xlim([currMin_reference currMax_reference])
ylim([currMin_target currMax_target])
xlabel(currXLabel,'FontSize',fontSize)
ylabel(currYLabel,'FontSize',fontSize)
axis square;

set(gca,'FontSize',fontSize)
box off;

%% show results for Fig 6C
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 6C');

% allocaate data
allGain_prefDir = allData(:,1);
allGain_nullDir = allData(:,2);
allGain_blank = allData(:,3);

% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get range for showing results
currMin_gain = min([allGain_prefDir(:);allGain_nullDir(:);allGain_blank(:)]);
currMax_gain = max([allGain_prefDir(:);allGain_nullDir(:);allGain_blank(:)]);
currMin_gain = currMin_gain*(1-0.05*sign(currMin_gain));
currMax_gain = currMax_gain*(1+0.05*sign(currMax_gain));
currMin_gain = min(currMin_gain,0);

shownReferenceName = { ...
    'blank', ...
    'blank', ...
    'nullDir', ...
    };
shownTargetName = { ...
    'nullDir', ...
    'prefDir', ...
    'prefDir', ...
    };

for pairIndex = 1:length(shownReferenceName)
    currShownReferenceName = shownReferenceName{pairIndex};
    currShownTargetName = shownTargetName{pairIndex};
    
    % get data to be shown
    cmd = ['currShownGain_reference = allGain_',currShownReferenceName,';'];
    eval(cmd);
    
    cmd = ['currShownGain_target = allGain_',currShownTargetName,';'];
    eval(cmd);
    
    % get statistics
    currPVal_pair_signrank = signrank(currShownGain_reference,currShownGain_target);
    
    % get positions for text
    currRange = currMax_gain-currMin_gain;
    textXPos = currMin_gain+currRange*0;
    
    textYPos_coef = currMin_gain+currRange*1.15;
    textYPos_signrank = currMin_gain+currRange*1.05;
    
    textString_coef = sprintf('N=%d', ...
        length(currShownGain_reference));
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    currXLabel = addRightSlash(['Gain_',currShownReferenceName]);
    currYLabel = addRightSlash(['Gain_',currShownTargetName]);
    
    % show comparison
    figRowIndex = 3;
    figColIndex = pairIndex*2-1;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    plot(currShownGain_reference,currShownGain_target,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot([currMin_gain currMax_gain],[currMin_gain currMax_gain],'k-.')
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currMin_gain currMax_gain])
    ylim([currMin_gain currMax_gain])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);