% this funtion aims to show results in S5 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S5_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some parameter
patchSaturation = 0.33; % saturation for patch of shaded errorbar
binNum = 21; % parameters for showing histogram

depthBoundary = [ ...
    0, ...
    0.3500, ...
    0.5800, ...
    0.7600, ....
    1.0000, ...
    ];

allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

layerID_output = [1 3];
layerID_input = [2 4];

shownLayerID = { ...
    layerID_output, ... % L2/3 & L5
    layerID_input, ... % L4 & L6
    };

shownLayerName = { ...
    'Output Layer', ...
    'Input Layer', ...
    };

shownLayerColor = { ...
    'b', ... % L23/output layer
    'r', ... % L4/input layer
    };

currShownLayerNum = 2;

currDepthMin = 0;
currDepthMax = 1;

withReferenceDataFlag = 0;
inputReferenceData = 0;

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% parameters for showing results
figColNum = 4;
figRowNum = 3;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.45; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.05; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% parameters for showing results
figRowNum = 2;
figColNum = 2;

% get position for showing results
leftGap = leftPos(1)+subFigWidth+0.05; % gap from left edge
rightGap = 1-leftPos(end)+0.05; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.18; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

leftPos = leftPos-leftPos(1)+0.1;
leftPos(3) = leftPos(2)+columnGap+subFigWidth;

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S5 Fig';
figureHandle(figureCount) = figure(figureCount);

shownConditionName = { ...
    'Blank', ...
    'Null Direction', ...
    'Preferred Direction', ...
    };

for conditionIndex = 1:length(shownConditionName)
    currShownConditionName =shownConditionName{conditionIndex};
    
    % get data
    switch currShownConditionName
        case 'Blank'
            [allData,~,~] = xlsread(fullFileName,'S5A Fig');
        case 'Null Direction'
            [allData,~,~] = xlsread(fullFileName,'S5B Fig');
        case 'Preferred Direction'
            [allData,~,~] = xlsread(fullFileName,'S5C Fig');
    end
    
    % allocate data
    pooledExpID = allData(:,1);
    pooledDepth = allData(:,2);
    pooledLayerID = allData(:,3);
    
    pooledData = allData(:,4);
    
    % get range for data
    currDataMin = 0;
    currDataMax = max(pooledData);
    if currDataMax == currDataMin
        currDataMax = currDataMin+1e-6;
    end
    currDataRange = currDataMax-currDataMin;
    currDataMax = currDataMin+currDataRange*1.05;
    
    % get index for electrode located in input layer or output layer
    pooledElecIndex_input = [];
    for layerIndex = 1:length(layerID_input)
        currLayerID = layerID_input(layerIndex);
        currElecIndex = find(pooledLayerID == currLayerID);
        
        pooledElecIndex_input = [pooledElecIndex_input;currElecIndex(:)];
    end
    
    pooledElecIndex_output = [];
    for layerIndex = 1:length(layerID_output)
        currLayerID = layerID_output(layerIndex);
        currElecIndex = find(pooledLayerID == currLayerID);
        
        pooledElecIndex_output = [pooledElecIndex_output;currElecIndex(:)];
    end
    
    %% show direct comparison of data between L4 and L23 or between input layer and output layer
    % get index for electrodes in given layer
    currElecIndex_reference = pooledElecIndex_input;
    currElecIndex_target = pooledElecIndex_output;
    
    layerName_reference = shownLayerName{2};
    layerName_target = shownLayerName{1};
    
    currXLabel = [layerName_reference];
    currYLabel = [layerName_target];
    
    % get experiment ID for each site
    uniqueExpID = unique(pooledExpID);
    uniqueExpNum = length(uniqueExpID);
    
    % initialize data for L4/input layer and L23/output layer
    pooledData_reference_median = [];
    pooledData_target_median = [];
    
    pooledData_reference_ste = [];
    pooledData_target_ste = [];
    
    pooledExpID_pair = [];
    
    % get data for input layer and output layer for each
    % unit
    for uniqueExpIndex = 1:uniqueExpNum
        tempExpID = uniqueExpID(uniqueExpIndex);
        
        % get data
        tempElecIndex = find(pooledExpID == tempExpID);
        
        tempElecIndex_reference = intersect(tempElecIndex,currElecIndex_reference);
        tempElecIndex_target = intersect(tempElecIndex,currElecIndex_target);
        
        if ~isempty(tempElecIndex_reference) && ...
                ~isempty(tempElecIndex_target)
            % get data
            tempData_reference = pooledData(tempElecIndex_reference);
            tempData_target = pooledData(tempElecIndex_target);
            
            % get statistics
            tempData_reference_median = median(tempData_reference);
            tempData_target_median = median(tempData_target);
            
            tempData_reference_std = std(tempData_reference);
            tempData_target_std = std(tempData_target);
            
            tempData_reference_ste = tempData_reference_std./sqrt(length(tempData_reference));
            tempData_target_ste = tempData_target_std./sqrt(length(tempData_target));
            
            % pool data
            pooledData_reference_median = [pooledData_reference_median(:);tempData_reference_median(:)];
            pooledData_target_median = [pooledData_target_median(:);tempData_target_median(:)];
            
            pooledData_reference_ste = [pooledData_reference_ste(:);tempData_reference_ste(:)];
            pooledData_target_ste = [pooledData_target_ste(:);tempData_target_ste(:)];
            
            pooledExpID_pair = [pooledExpID_pair(:);tempExpID];
        end
    end
    
    if isempty(pooledData_reference_median)
        pooledData_reference_median = currDataMin;
        pooledData_target_median = currDataMin;
        
        pooledData_reference_ste = 0;
        pooledData_target_ste = 0;
    end
    
    % get statistics
    [currCoef_pair_coef,currPVal_pair_coef] = corr(pooledData_reference_median,pooledData_target_median,'type','Spearman');
    
    currPVal_pair_signrank = signrank(pooledData_reference_median,pooledData_target_median);
    
    % do linear fitting
    fitXX_data = [currDataMin,currDataMax];
    
    currFitCoef = polyfit(pooledData_reference_median,pooledData_target_median,1);
    currFitYY = currFitCoef*[fitXX_data;1,1];
    
    shownDataLabel = [currShownConditionName,' Response'];
    
    %% show direct comparison
    % range for showing data
    currXMin = currDataMin;
    currXMax = currDataMax;
    currXRange = currXMax-currXMin;
    
    currYMin = currDataMin;
    currYMax = currDataMax;
    currYRange = currYMax-currYMin;
    
    textXPos = currXMin+currXRange*0;
    textYPos_coef = currYMin+currYRange*1.25;
    %     textYPos_fit = currYMin+currYRange*1.15;
    %     textYPos_signrank = currYMin+currYRange*1.05;
    
    textYPos_signrank = currYMin+currYRange*1.15;
    
    %     textString_coef = sprintf('N=%d,r=%.2g,p=%.3g;signrank:p=%.3g', ...
    %         length(pooledData_reference_median),currCoef_pair_coef,currPVal_pair_coef,currPVal_pair_signrank);
    %     textString_fit = sprintf('y=%.2fx+%.2f',currFitCoef(1),currFitCoef(2));
    %     textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    textString_coef = sprintf('N=%d,r=%.2g,p=%.3g', ...
        length(pooledData_reference_median),currCoef_pair_coef,currPVal_pair_coef);
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    % create axis
    figRowIndex = 2;
    figColIndex = conditionIndex;
    
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    %     currHeight = subFigHeight*0.9;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    hold on;
    
    % plot(fitXX_data,currFitYY,'k-','LineWidth',lineWidth)
    plot([currXMin currXMax],[currYMin currYMax],'k-.')
    if withReferenceDataFlag == 1
        plot([currXMin currXMax],inputReferenceData+[0 0],'k-.')
        plot(inputReferenceData+[0 0],[currYMin currYMax],'k-.')
    end
    
    % show data for each animal
    for expIndex = 1:length(pooledData_reference_median)
        % get data for current experiment
        currData_reference_median = pooledData_reference_median(expIndex);
        currData_target_median = pooledData_target_median(expIndex);
        
        currData_reference_ste = pooledData_reference_ste(expIndex);
        currData_target_ste = pooledData_target_ste(expIndex);
        
        % show data
        currEBHandle = errorbar(currData_reference_median,currData_target_median,currData_reference_ste,'o','horizontal');
        set(currEBHandle,'color','k','markeredgecolor','k','markerfacecolor','k')
        currEBHandle = errorbar(currData_reference_median,currData_target_median,currData_target_ste,'o');
        set(currEBHandle,'color','k','markeredgecolor','k','markerfacecolor','k')
    end
    
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    %     text(textXPos,textYPos_fit,textString_fit,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    title(shownDataLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
    
    %% get distribution/cumulative distribution of response properties in each layer
    % get data to be shown
    currPooledLayerID = pooledLayerID;
    currPooledData = pooledData;
    
    % get bin for statistics
    currEdge_data = linspace(currDataMin,currDataMax,binNum);
    
    currEdgeDiff_data = (currEdge_data(2)-currEdge_data(1))/2;
    currShownEdge_data = currEdge_data+currEdgeDiff_data;
    currShownEdge_data = currShownEdge_data(1:(end-1));
    
    % initialize histogram and statistics
    allHist_data = zeros(currShownLayerNum,binNum-1);
    allCumDistribution_data = zeros(currShownLayerNum,binNum-1);
    allElecNum_data = zeros(currShownLayerNum,1);
    
    allMedian_data = zeros(currShownLayerNum,1);
    allMean_data = zeros(currShownLayerNum,1);
    allStd_data = zeros(currShownLayerNum,1);
    allSte_data = zeros(currShownLayerNum,1);
    
    allPVal_median_withinLayer_signtest = zeros(currShownLayerNum,1); % compare median value with reference data for each layer, will not be used
    allPVal_median_withinLayer_ranksum = zeros(currShownLayerNum,1); % compare median value with reference data for each layer, will not be used
    
    allPairData = cell(currShownLayerNum,1);
    
    % get histogram and statistics
    for layerIndex = 1:currShownLayerNum
        currShownLayerID = shownLayerID{layerIndex};
        
        % get data
        currValidElecIndex = [];
        for idIndex = 1:length(currShownLayerID)
            tempShownLayerID = currShownLayerID(idIndex);
            tempValidElecIndex = find(currPooledLayerID == tempShownLayerID);
            currValidElecIndex = [currValidElecIndex(:);tempValidElecIndex(:)];
        end
        currData = currPooledData(currValidElecIndex);
        
        % get histogram
        currHist_data = histcounts(currData,currEdge_data);
        currHist_data = currHist_data./sum(currHist_data);
        
        % get cumulative distribution
        currCumDistribution_data = cumsum(currHist_data);
        
        % get statistics
        currMedian_data = median(currData);
        currMean_data = mean(currData);
        currStd_data = std(currData);
        currSte_data = currStd_data./sqrt(length(currData));
        
        % do sign test
        currPVal_signtest = signtest(currData,inputReferenceData);
        currPVal_ranksum = ranksum(currData,inputReferenceData);
        
        % pool data
        allHist_data(layerIndex,:) = currHist_data;
        allCumDistribution_data(layerIndex,:) = currCumDistribution_data;
        allElecNum_data(layerIndex) = length(currData);
        
        allMedian_data(layerIndex) = currMedian_data;
        allMean_data(layerIndex) = currMean_data;
        allStd_data(layerIndex) = currStd_data;
        allSte_data(layerIndex) = currSte_data;
        
        allPVal_median_withinLayer_signtest(layerIndex) = currPVal_signtest;
        allPVal_median_withinLayer_ranksum(layerIndex) = currPVal_ranksum;
        
        allPairData{layerIndex} = currData;
    end
    
    % get statistical comparison of median value
    if sum(isnan(allPairData{1})) == length(allPairData{1}) || ...
            sum(isnan(allPairData{2})) == length(allPairData{2})
        currPVal_median_acrossLayer_ranksum = 1; % compare median value across layers
        currPVal_median_acrossLayer_kstest = 1; % compare distribution across layers, will not used
    else
        currPVal_median_acrossLayer_ranksum = ranksum(allPairData{1},allPairData{2}); % compare median value across layers
        [~,currPVal_median_acrossLayer_kstest] = kstest2(allPairData{1},allPairData{2},'Tail','larger'); % compare distribution across layers, will not used
    end
    
    %% show distribution/cumulative distribution of response properties at different layers
    % get range for showing results
    currXLabel = shownDataLabel;
    
    currXMin = currEdge_data(1);
    currXMax = currEdge_data(end);
    currXRange = currXMax-currXMin;
    
    currYMin = 0;
    currYMax = 1;
    currYRange = currYMax-currYMin;
    
    % pre-define position for showing and comparing median
    currYPos_marker_median = currYMin+currYRange*1.03; % position for showing median and ste
    
    currYPos_line_median = currYMin+currYRange*1.06; % position for horizontal lines connecting two medians
    
    currXPos_pval_median = mean(allMedian_data);
    currYPos_pval_median = currYMin+currYRange*1.08; % position for showing significance
    
    currYMax = currYMin+currYRange*1.1;
    
    % show histogram and statistics
    allLegendHandle = zeros(currShownLayerNum,1);
    
    figRowIndex = 1;
    figColIndex = conditionIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    hold on;
    for layerIndex = 1:currShownLayerNum
        currShownLayerColor = shownLayerColor{layerIndex};
        
        % get data
        currCumDistribution_data = allCumDistribution_data(layerIndex,:);
        
        % get median value
        currMedian_data = allMedian_data(layerIndex);
        currMean_data = allMean_data(layerIndex);
        currStd_data = allStd_data(layerIndex);
        currSte_data = allSte_data(layerIndex);
        
        % show cumulative distribution
        currLegendHandle = plot(currShownEdge_data,currCumDistribution_data,'-','Color',currShownLayerColor,'LineWidth',lineWidth);
        allLegendHandle(layerIndex) = currLegendHandle;
        
        % show median value
        errorbar(currMedian_data,currYPos_marker_median,currSte_data, ...
            '-','horizontal','Color',currShownLayerColor)
        plot(currMedian_data,currYPos_marker_median,'o', ...
            'MarkerEdgeColor',currShownLayerColor,'MarkerFaceColor',currShownLayerColor)
    end
    if withReferenceDataFlag == 1
        plot(inputReferenceData+[0 0],[currYMin currYMax],'k-.')
    end
    plot([currXMin currXMax],0.5+[0 0],'k-.')
    
    % show significance of median across layers
    if currPVal_median_acrossLayer_ranksum < 0.001
        currMarker = '***';
    elseif currPVal_median_acrossLayer_ranksum < 0.01
        currMarker = '**';
    elseif currPVal_median_acrossLayer_ranksum < 0.05
        currMarker = '*';
    else
        currMarker = 'ns';
    end
    plot(allMedian_data,currYPos_line_median+[0 0],'k-','LineWidth',lineWidth)
    text(currXPos_pval_median,currYPos_pval_median,currMarker,'Color','k','FontSize',fontSize,'HorizontalAlignment','center')
    
    % add legend
    currLegendHandle = legend(allLegendHandle,shownLayerName,'location','southeast');
    set(currLegendHandle,'fontsize',fontSize)
    
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel('Response(spk/sec)','FontSize',fontSize)
    ylabel('Proportion','FontSize',fontSize)
    title(currShownConditionName,'FontSize',fontSize)
    set(gca,'YColor','k')
    
    axis square;
    set(gca,'FontSize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);