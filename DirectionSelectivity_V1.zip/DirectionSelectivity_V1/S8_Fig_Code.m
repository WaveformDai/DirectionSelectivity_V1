% this funtion aims to show results in S5 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-16-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S8_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some paramter
fitR2Thre = 0.8;

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

patchSaturation = 0.33; % saturation for patch of shaded errorbar

% get position for showing results
figRowNum = 2;
figColNum = 3;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.05; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.11; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.16; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S8 Fig';
figureHandle(figureCount) = figure(figureCount);

%% show results for S8C Fig
% get data
[allData,~,~] = xlsread(fullFileName,'S8C Fig');

% allocate data
allAdjR2_untuned = allData(:,1);
allAdjR2_tuned = allData(:,2);

% get statistics
currPVal_pair_signrank = signrank(allAdjR2_untuned,allAdjR2_tuned);

% get range for shown result
currMin = 0;
currMax = 1;
currRange = currMax-currMin;

textXPos = currMin+currRange*0;
textYPos_coef = currMin+currRange*1.15;
textYPos_signrank = currMin+currRange*1.05;

textString_coef = sprintf('N=%d', ...
    length(allAdjR2_untuned));
textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);

currXLabel = 'adjR2: Untuned Gain';
currYLabel = 'adjR2: Tuned Gain';

% show comparison
figRowIndex = 2;
figColIndex = 1;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex)+0.05;
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
plot(allAdjR2_untuned,allAdjR2_tuned,'o', ...
    'MarkerEdgeColor','k','MarkerFaceColor','k')
hold on;
plot([currMin currMax],[currMin currMax],'k-.')
text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
plot(fitR2Thre+[0 0],[currMin currMax],'k-.')
plot([currMin currMax],fitR2Thre+[0 0],'k-.')
xlim([currMin currMax])
ylim([currMin currMax])
xlabel(currXLabel,'FontSize',fontSize)
ylabel(currYLabel,'FontSize',fontSize)
%                 title(shownDataLabel,'FontSize',fontSize)
axis square;

set(gca,'FontSize',fontSize)
box off;

%% show results for S8ABD Fig
% get data
[allData,~,~] = xlsread(fullFileName,'S8ABD Fig');

% allocate data
allDSI_untuned = allData(:,1);
allDSI_tuned = allData(:,2);
allDSI_output = allData(:,3);
allDSI_input = allData(:,4);

% pre-define some paramters
shownReferenceName = { ...
    'Input Layers', ...
    'Output Layers', ...
    'Output Layers', ...
    };
shownTargetName = { ...
    'Untuned Gain', ...
    'Untuned Gain', ...
    'tuned', ...
    };

shownReferenceName_brief = { ...
    'input', ...
    'output', ...
    'output', ...
    };
shownTargetName_brief = { ...
    'untuned', ...
    'untuned', ...
    'tuned', ...
    };

for pairIndex = 1:length(shownReferenceName)
    currShownReferenceName = shownReferenceName{pairIndex};
    currShownTargetName = shownTargetName{pairIndex};
    
    currShownReferenceName_brief = shownReferenceName_brief{pairIndex};
    currShownTargetName_brief = shownTargetName_brief{pairIndex};
    
    % get data to be shown
    cmd = ['currData_reference = allDSI_',currShownReferenceName_brief,';'];
    eval(cmd);
    
    cmd = ['currData_target = allDSI_',currShownTargetName_brief,';'];
    eval(cmd);
    
    % get statistics
    currPVal_pair_signrank = signrank(currData_reference,currData_target);
    
    % get range for shown result
    currMin = 0;
    currMax = 1;
    currRange = currMax-currMin;
    
    textXPos = currMin+currRange*0;
    textYPos_coef = currMin+currRange*1.15;
    textYPos_signrank = currMin+currRange*1.05;
    
    textString_coef = sprintf('N=%d', ...
        length(currData_reference));
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    currXLabel = ['DSI:',currShownReferenceName];
    currYLabel = ['DSI:',currShownTargetName];
    
    % show comparison
    figRowIndex = 1;
    figColIndex = pairIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    plot(currData_reference,currData_target,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot([currMin currMax],[currMin currMax],'k-.')
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currMin currMax])
    ylim([currMin currMax])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% show results for S8E Fig
% get data
[allData,~,~] = xlsread(fullFileName,'S8E Fig');

% allocate data
fitDir = allData(:,1);

currShownGain_center = allData(:,2);
currShownGain_ste = allData(:,3);

currGain_blank_center = allData(1,4);
currGain_blank_ste = allData(1,5);

% get position for showing results
figRowNum = 4;
figColNum = 4;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.03; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

figRowNum = 3;
leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get range for showing results
currXMin = fitDir(1);
currXMax = fitDir(end);

currYMin = min([currShownGain_center(:)-currShownGain_ste(:)]);
currYMax = max([currShownGain_center(:)+currShownGain_ste(:)]);
currYMin = currYMin*(1-0.05*sign(currYMin));
currYMax = currYMax*(1+0.05*sign(currYMax));
currYMin = min(currYMin,0);

xxTickPos = 0:50:350;
xxTickLabel = 0:50:350;

% show mean/median dir tuning of gain
figRowIndex = 3;
figColIndex = 3;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex)+0.05;
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
hold on;
curSEHandle = shadedErrorBar([currXMin currXMax],currGain_blank_center+[0 0],currGain_blank_ste+[0 0], ...
    'patchSaturation',patchSaturation);
set(curSEHandle.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle.patch,'FaceColor','k')
set(curSEHandle.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle.edge(2),'Color','none','LineWidth',lineWidth/2)

curSEHandle = shadedErrorBar(fitDir,currShownGain_center,currShownGain_ste, ...
    'patchSaturation',patchSaturation);
set(curSEHandle.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle.patch,'FaceColor','k')
set(curSEHandle.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle.edge(2),'Color','none','LineWidth',lineWidth/2)

xlabel('Direction','FontSize',fontSize)
ylabel('Gain','FontSize',fontSize)
xlim([currXMin currXMax])
ylim([currYMin currYMax])
set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)

set(gca,'FontSize',fontSize)
box off;

%% show results for S8F Fig
% get data
[allData,~,~] = xlsread(fullFileName,'S8F Fig');

% allocate data
currData_reference = allData(:,1);
currData_target = allData(:,2);

% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get statistics
[currCoef_pair_coef,currPVal_pair_coef] = corr(currData_reference,currData_target,'type','Spearman');

% get range for shown result
currMin_reference = min([currData_reference(:)]);
currMax_reference = max([currData_reference(:)]);
currMin_reference = currMin_reference*(1-0.05*sign(currMin_reference));
currMax_reference = currMax_reference*(1+0.05*sign(currMax_reference));
currMin_reference = min(currMin_reference,0);
currRange_reference = currMax_reference-currMin_reference;

currMin_target = min([currData_target(:)]);
currMax_target = max([currData_target(:)]);
currMin_target = currMin_target*(1-0.05*sign(currMin_target));
currMax_target = currMax_target*(1+0.05*sign(currMax_target));
currMin_target = min(currMin_target,0);
currRange_target = currMax_target-currMin_target;

% do linear fitting
fitXX_data = [currMin_reference,currMax_reference];

currFitCoef = polyfit(currData_reference,currData_target,1);
currFitYY = currFitCoef*[fitXX_data;1,1];

textXPos = currMin_reference+currRange_reference*0;
textYPos_coef = currMin_target+currRange_target*1.15;

textString_coef = sprintf('N=%d,r=%.2g,p=%.3g', ...
    length(currData_reference),currCoef_pair_coef,currPVal_pair_coef);

currXLabel = 'DSI: Output Layers';
currYLabel = 'DSI: Gain';

% show comparison
figRowIndex = 4;
figColIndex = 6;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex)+0.05;
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
plot(currData_reference,currData_target,'o', ...
    'MarkerEdgeColor','k','MarkerFaceColor','k')
hold on;
plot(fitXX_data,currFitYY,'k-','LineWidth',lineWidth)
text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
xlim([currMin_reference currMax_reference])
ylim([currMin_target currMax_target])
xlabel(currXLabel,'FontSize',fontSize)
ylabel(currYLabel,'FontSize',fontSize)
axis square;

set(gca,'FontSize',fontSize)
box off;

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);