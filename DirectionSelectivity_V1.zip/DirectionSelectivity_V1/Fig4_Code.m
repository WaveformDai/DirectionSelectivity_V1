% this funtion aims to show results in Fig 4 for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig4_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

patchSaturation = 0.33; % saturation for patch of shaded errorbar

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig4';
figureHandle(figureCount) = figure(figureCount);

%% show results for Fig 4A
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 4A');

% get data to be shown
currDir = allData(:,1);

currShownData_reference_center = allData(:,2);
currShownData_target_center = allData(:,3);

currShownData_reference_error = allData(:,4);
currShownData_target_error = allData(:,5);

currF0_blank_reference_center = allData(1,6);
currF0_blank_target_center = allData(1,7);

currF0_blank_reference_error = allData(1,8);
currF0_blank_target_error = allData(1,9);

currValidElecNum_reference = allData(1,10);
currValidElecNum_target = allData(1,11);

% get positions for showing results
figRowNum = 4;
figColNum = 4;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.03; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

currReferenceLayerColor = 'b'; % output layer
currTargetLayerColor = 'r'; % input layer

currReferenceLayerName = 'Output Layer';
currTargetLayerName = 'Input Layer';

currReferencePatchColor = currReferenceLayerColor;
currTargetPatchColor = currTargetLayerColor;

% get range for showing results
currXMin = min(currDir);
currXMax = max(currDir);
currXRange = currXMax-currXMin;

currYMin = min([currShownData_reference_center(:)-currShownData_reference_error(:); ...
    currShownData_target_center(:)-currShownData_target_error(:)]);
currYMax = max([currShownData_reference_center(:)+currShownData_reference_error(:); ...
    currShownData_target_center(:)+currShownData_target_error(:)]);
currYMin = currYMin*(1-0.05*sign(currYMin));
currYMax = currYMax*(1+0.05*sign(currYMax));
currYMin = min(currYMin,0);
%             currYMax = max(currYMax,1.1);
if currYMax == currYMin
    currYMax = currYMin+1e-6;
end
if isnan(currYMin) || isnan(currYMax)
    currYMin = 0;
    currYMax = 1e-6;
end
currYRange = currYMax-currYMin;

textXPos = currXMin+currXRange*0.4;
textYPos_reference = currYMin+currYRange*0.9;
textYPos_target = currYMin+currYRange*0.8;

xxTickPos = 0:50:350;
xxTickLabel = 0:50:350;

% show results
figRowIndex = 1;
figColIndex = 1;

currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currHandle_FitSum = subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight]);
hold on;

% show ori/dir tuning in output layer
curSEHandle_reference = shadedErrorBar(currDir,currShownData_reference_center,currShownData_reference_error, ...
    'patchSaturation',patchSaturation);
set(curSEHandle_reference.mainLine,'Color',currReferenceLayerColor,'LineWidth',lineWidth)
set(curSEHandle_reference.patch,'FaceColor',currReferencePatchColor)
set(curSEHandle_reference.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_reference.edge(2),'Color','none','LineWidth',lineWidth/2)

% show blank response
curSEHandle_blank_reference = shadedErrorBar([currXMin currXMax],currF0_blank_reference_center+[0 0],currF0_blank_reference_error+[0 0], ...
    'patchSaturation',patchSaturation);
set(curSEHandle_blank_reference.mainLine,'Color',currReferenceLayerColor,'LineWidth',lineWidth)
set(curSEHandle_blank_reference.patch,'FaceColor',currReferencePatchColor)
set(curSEHandle_blank_reference.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_blank_reference.edge(2),'Color','none','LineWidth',lineWidth/2)

text(textXPos,textYPos_reference,sprintf('%s:N=%d',currReferenceLayerName,currValidElecNum_reference), ...
    'FontSize',fontSize,'Color',currReferenceLayerColor)

% show ori/dir tuning in input layer
curSEHandle_target = shadedErrorBar(currDir,currShownData_target_center,currShownData_target_error, ...
    'patchSaturation',patchSaturation);
set(curSEHandle_target.mainLine,'Color',currTargetLayerColor,'LineWidth',lineWidth)
set(curSEHandle_target.patch,'FaceColor',currTargetPatchColor)
set(curSEHandle_target.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_target.edge(2),'Color','none','LineWidth',lineWidth/2)

% show blank response
curSEHandle_blank_target = shadedErrorBar([currXMin currXMax],currF0_blank_target_center+[0 0],currF0_blank_target_error+[0 0], ...
    'patchSaturation',patchSaturation);
set(curSEHandle_blank_target.mainLine,'Color',currTargetLayerColor,'LineWidth',lineWidth)
set(curSEHandle_blank_target.patch,'FaceColor',currTargetPatchColor)
set(curSEHandle_blank_target.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_blank_target.edge(2),'Color','none','LineWidth',lineWidth/2)

text(textXPos,textYPos_target,sprintf('%s:N=%d',currTargetLayerName,currValidElecNum_target), ...
    'FontSize',fontSize,'Color',currTargetLayerColor)

xlim([currXMin currXMax])
ylim([currYMin currYMax])

set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)
xlabel('Direction','FontSize',fontSize)
ylabel('Response(spk/s)','FontSize',fontSize)

set(gca,'FontSize',fontSize)
box off;

%% show results for Fig 4B
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 4B');

% get data to be shown
currDir = allData(:,1);

currShownRatio_unit_pair_center = allData(:,2);
currShownRatio_unit_pair_ste = allData(:,3);

currShownRatio_blank_unit_pair_center = allData(1,4);
currShownRatio_blank_unit_pair_ste = allData(1,5);

% get range for showing results
currXMin = min(currDir);
currXMax = max(currDir);
currXRange = currXMax-currXMin;

currYMin = min([currShownRatio_unit_pair_center(:)-currShownRatio_unit_pair_ste(:)]);
currYMax = max([currShownRatio_unit_pair_center(:)+currShownRatio_unit_pair_ste(:)]);
currYMin = currYMin*(1-0.05*sign(currYMin));
currYMax = currYMax*(1+0.05*sign(currYMax));
currYMin = min(currYMin,0);
%             currYMax = max(currYMax,1.1);
if currYMax == currYMin
    currYMax = currYMin+1e-6;
end
if isnan(currYMin) || isnan(currYMax)
    currYMin = 0;
    currYMax = 1e-6;
end
currYRange = currYMax-currYMin;

% show averaged ori/dir tuning across all exp pairs
figRowIndex = 1;
figColIndex = 2;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currHandle_FitSum = subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight]);
hold on;

% show blank response
curSEHandle_blank_reference = shadedErrorBar([currXMin currXMax],currShownRatio_blank_unit_pair_center+[0 0],currShownRatio_blank_unit_pair_ste+[0 0], ...
    'patchSaturation',patchSaturation); % added on 2024-09-17
set(curSEHandle_blank_reference.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle_blank_reference.patch,'FaceColor','k')
set(curSEHandle_blank_reference.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_blank_reference.edge(2),'Color','none','LineWidth',lineWidth/2)

% show ori/dir tuning
curSEHandle_reference = shadedErrorBar(currDir,currShownRatio_unit_pair_center,currShownRatio_unit_pair_ste, ...
    'patchSaturation',patchSaturation);
set(curSEHandle_reference.mainLine,'Color','k','LineWidth',lineWidth)
set(curSEHandle_reference.patch,'FaceColor','k')
set(curSEHandle_reference.edge(1),'Color','none','LineWidth',lineWidth/2)
set(curSEHandle_reference.edge(2),'Color','none','LineWidth',lineWidth/2)

xlim([currXMin currXMax])
ylim([currYMin currYMax])

set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)
xlabel('Direction','FontSize',fontSize)
ylabel('Response Ratio','FontSize',fontSize)

set(gca,'FontSize',fontSize)
box off;

%% show results for Fig 4C
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 4C-D');

% get data to be shown
currShownRatio_pref = allData(:,1);
currShownRatio_null = allData(:,2);
currShownRatio_blank = allData(:,3);

% get position for showing results
figRowNum = 4; % different results
figColNum = 4; % different layer pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.03; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% pre-define some parameters
binNum = 9;

dirTypeName = { ...
    'Blank', ...
    'Null Direction', ...
    'Preferred Direction', ...
    };

% get range for histogram
currMin_ratio = min([currShownRatio_blank(:);currShownRatio_null(:);currShownRatio_pref(:)]);
currMax_ratio = max([currShownRatio_blank(:);currShownRatio_null(:);currShownRatio_pref(:)]);
currMin_ratio = currMin_ratio*(1-0.05*sign(currMin_ratio));
currMax_ratio = currMax_ratio*(1+0.05*sign(currMax_ratio));
currMin_ratio = min(currMin_ratio,0);

% get bin for histogram
currEdge_ratio = linspace(currMin_ratio,currMax_ratio,binNum);

currEdgeDiff_ratio = (currEdge_ratio(2)-currEdge_ratio(1))/2;
currShownEdge_ratio = currEdge_ratio+currEdgeDiff_ratio;
currShownEdge_ratio = currShownEdge_ratio(1:(end-1));

for dirTypeIndex = 1:length(dirTypeName)
    currDirTypeName = dirTypeName{dirTypeIndex};
    
    % get data
    switch currDirTypeName
        case 'Blank'
            currShownRatio = currShownRatio_blank; % pairNum*1
        case 'Null Direction'
            currShownRatio = currShownRatio_null; % pairNum*1
        case 'Preferred Direction'
            currShownRatio = currShownRatio_pref; % pairNum*1
    end
    
    % get histogram
    currHist_ratio = histcounts(currShownRatio,currEdge_ratio);
    currHist_ratio = currHist_ratio./sum(currHist_ratio);
    
    % get cumulative distribution
    currCumDistribution_ratio = cumsum(currHist_ratio);
    
    % get statistics
    currMedian_ratio = median(currShownRatio);
    currMean_ratio = mean(currShownRatio);
    currStd_ratio = std(currShownRatio);
    currSte_ratio = currStd_ratio./sqrt(length(currShownRatio));
    
    % do sign test
    currPVal_signtest = signtest(currShownRatio,1); % check ratio is significantly different from 1
    currPVal_ranksum = ranksum(currShownRatio,1); % check ratio is significantly different from 1
    
    % range for showing results
    currXMin = currEdge_ratio(1)-currEdgeDiff_ratio;
    currXMax = currEdge_ratio(end)+currEdgeDiff_ratio*2;
    currXRange = currXMax-currXMin;
    
    currHistMin = 0;
    currHistMax = max(currHist_ratio(:));
    currHistRange = currHistMax-currHistMin;
    
    errorbarYPos = currHistMin+currHistRange*1.05;
    
    currYMin = currHistMin;
    currYMax = currHistMin+currHistRange*1.1;
    currYRange = currYMax-currYMin;
    
    currXLabel_ratio = addRightSlash(['Response Ratio']);
    
    textXPos = currXMin+currXRange*0.6;
    textYPos_exp = currYMin+currYRange*0.95;
    textYPos_pval = currYMin+currYRange*0.75;
    
    % show histogram
    figRowIndex = 2;
    figColIndex = dirTypeIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex)-0.1;
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    currBarHandle = bar(currShownEdge_ratio,currHist_ratio(:));
    set(currBarHandle,'EdgeColor','k','FaceColor','k')
    hold on;
    errorbar(currMedian_ratio,errorbarYPos,currSte_ratio, ...
        '-','horizontal','Color','k')
    plot(currMedian_ratio,errorbarYPos,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    %                 plot([0 0],[currYMin currYMax],'k-.')
    plot([1 1],[currYMin currYMax],'k-.')
    text(textXPos,textYPos_exp,sprintf('N=%d',length(currShownRatio)),'FontSize',fontSize)
    text(textXPos,textYPos_pval,sprintf('p=%.3g',currPVal_signtest),'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel(currXLabel_ratio,'FontSize',fontSize)
    ylabel('Proportion','FontSize',fontSize)
    title(currDirTypeName,'FontSize',fontSize)
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% show results for Fig 4C
% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% pre-define some parameters
dirPairName_reference = { ...
    'Blank', ...
    'Blank', ...
    'Null Direction', ...
    };
dirPairName_target = { ...
    'Null Direction', ...
    'Preferred Direction', ...
    'Preferred Direction', ...
    };

dirPairName_reference_brief = { ...
    'blank', ...
    'blank', ...
    'nullDir', ...
    };
dirPairName_target_brief = { ...
    'nullDir', ...
    'prefDir', ...
    'prefDir', ...
    };

for dirPairIndex = 1:length(dirPairName_reference)
    currDirPairName_reference = dirPairName_reference{dirPairIndex};
    currDirPairName_target = dirPairName_target{dirPairIndex};
    
    currDirPairName_reference_brief = dirPairName_reference_brief{dirPairIndex};
    currDirPairName_target_brief = dirPairName_target_brief{dirPairIndex};
    
    % get data
    switch currDirPairName_reference
        case 'Blank'
            currShownRatio_reference = currShownRatio_blank; % pairNum*1
        case 'Null Direction'
            currShownRatio_reference = currShownRatio_null; % pairNum*1
        case 'Preferred Direction'
            currShownRatio_reference = currShownRatio_pref; % pairNum*1
    end
    
    switch currDirPairName_target
        case 'Blank'
            currShownRatio_target = currShownRatio_blank; % pairNum*1
        case 'Null Direction'
            currShownRatio_target = currShownRatio_null; % pairNum*1
        case 'Preferred Direction'
            currShownRatio_target = currShownRatio_pref; % pairNum*1
    end
    
    % get statistics
    [currCoef_pair_coef,currPVal_pair_coef] = corr(currShownRatio_reference,currShownRatio_target,'type','Spearman');
    
    currPVal_pair_signrank = signrank(currShownRatio_reference,currShownRatio_target);
    
    % do linear fitting
    fitXX_data = [currMin_ratio,currMax_ratio];
    
    currFitCoef = polyfit(currShownRatio_reference,currShownRatio_target,1);
    currFitYY = currFitCoef*[fitXX_data;1,1];
    
    currRange = currMax_ratio-currMin_ratio;
    textXPos = currMin_ratio+currRange*0;
    
    textYPos_coef = currMin_ratio+currRange*1.15;
    textYPos_signrank = currMin_ratio+currRange*1.05;
    textYPos_title = currMin_ratio+currRange*0.95;
    
    textString_coef = sprintf('N=%d,r=%.2g,p=%.3g', ...
        length(currShownRatio_reference),currCoef_pair_coef,currPVal_pair_coef);
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    currXLabel = addRightSlash(['Response Ratio_',currDirPairName_reference_brief]);
    currYLabel = addRightSlash(['Response Ratio_',currDirPairName_target_brief]);
    
    % show comparison
    figRowIndex = 3;
    figColIndex = dirPairIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex)-0.2;
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    plot(currShownRatio_reference,currShownRatio_target,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot(fitXX_data,currFitYY,'k-','LineWidth',lineWidth)
    plot([currMin_ratio currMax_ratio],[currMin_ratio currMax_ratio],'k-.')
    plot([1 1],[currMin_ratio currMax_ratio],'k-.')
    plot([currMin_ratio currMax_ratio],[1 1],'k-.')
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currMin_ratio currMax_ratio])
    ylim([currMin_ratio currMax_ratio])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);