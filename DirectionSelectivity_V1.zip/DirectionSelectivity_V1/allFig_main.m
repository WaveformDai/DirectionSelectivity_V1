% this funtion aims to show results for all figures and supplementary
% figures for paper 'Cortical direction selectivity increases from the
% input to the output layers of visual cortex'
% created on 11-18-2024

clear all;
close all;
clc;

% add current file path into search path
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
addpath(genpath(filePath));

% show Fig1
Fig1B_Code;
Fig1C_E_Code;

% show Fig2
Fig2_Code;

% show Fig3
Fig3_Code;

% show Fig4
Fig4_Code;

% show Fig5
Fig5_Code;

% show Fig6
Fig6_Code;

% show Fig7
Fig7_Code;

% show S1 Fig
S1_Fig_Code;

% show S2 Fig
S2_Fig_Code;

% show S3 Fig
S3A_C_Fig_Code;
S3D_G_Fig_Code;
S3H_I_Fig_Code;

% show S4 Fig
S4_Fig_Code;

% show S5 Fig
S5_Fig_Code;

% show S6 Fig
S6_Fig_Code;

% show S7 Fig
S7_Fig_Code;

% show S8 Fig
S8_Fig_Code;

% show S9 Fig
S9_Fig_Code;

% show S10 Fig
S10_Fig_Code;

% show S11 Fig
S11_Fig_Code;

% show S12 Fig
S12_Fig_Code;

% show S13 Fig
S13_Fig_Code;
