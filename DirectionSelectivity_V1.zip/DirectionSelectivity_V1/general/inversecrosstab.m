function [xVec,yVec] = inversecrosstab(tab)
% INVERSECROSSTAB takes table of values (as would be output by CROSSTAB) and creates
% X and Y vectors that would have led to that cross-tabulation table

[rowNum,colNum] = size(tab);

[xVec,yVec] = deal([]); % initialize data as empty matrix

val = 0;
for rowIndex = 1:rowNum
    val = val + 1;
    for colIndex = 1:colNum
        xVec = [xVec;repmat(val,[tab(rowIndex,colIndex),1])];
        yVec = [yVec;repmat(colIndex, [tab(rowIndex,colIndex),1])];
    end
end

end