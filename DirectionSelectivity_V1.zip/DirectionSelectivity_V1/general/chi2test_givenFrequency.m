% this function aims to do pearson's chi-square test given only frequency
% data, not raw data(which was needed by crosstab)
% from https://in.mathworks.com/matlabcentral/answers/1811930-performing-chi-square-test
% created on 2022-10-07

% initialize frequency data
% M = [250  200  450;
%     50 1000 1050;
%     300 1200 1500];

M = [250  200;
    50 1000];

% re-generate false raw data
[x,y] = inversecrosstab(M);

% do chi-square test using crosstab
[tbl,chi2,p,labels] = crosstab(x,y);