function newString = addRightSlash(inputString,searchString)

if nargin == 1
    searchString = '_';
end
replaceString = ['\',searchString];

% newString = []; %%% title name of each figure
% for ii = 1:length(inputString)
%     if strcmp(inputString(ii),'_')
%         newString = [newString,'\_'];
%     else
%         newString = [newString,inputString(ii)];
%     end
% end

if iscell(inputString)
    newString = inputString;
    for ii = 1:length(inputString)
        tempString = inputString{ii};
        
        tempNewString = [];
        for jj = 1:length(tempString)
            if strcmp(tempString(jj),searchString)
                tempNewString = [tempNewString,replaceString];
            else
                tempNewString = [tempNewString,tempString(jj)];
            end
        end
        newString{ii} = tempNewString;
    end
else
    newString = []; %%% title name of each figure
    for ii = 1:length(inputString)
        if strcmp(inputString(ii),searchString)
            newString = [newString,replaceString];
        else
            newString = [newString,inputString(ii)];
        end
    end
end

end