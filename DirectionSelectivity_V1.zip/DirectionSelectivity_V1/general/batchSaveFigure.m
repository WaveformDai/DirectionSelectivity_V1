function batchSaveFigure(savedFilePath,allFigName,allFigHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag)
% this function aims to save figures with given handle and file name
% input:
% savedFilePath: file path in which fiugres will be saved;
% allFigName; name of all fiures;
% allFigHandle; handles for all figures;
% deleteOldResultFlag: if(1) or not(0) delete previously saved figures
% addFigIDFlag: if(1) or not(0) add ID of figure during naming
% startFigID: ID to start naming
% created on 2021-08-19

% get figure number
allFigCount = length(allFigName);

if ~exist('deleteOldResultFlag','var')
    deleteOldResultFlag = 0;
end

if ~exist('addFigIDFlag','var')
    addFigIDFlag = 0;
end

if ~exist('startFigID','var')
    startFigID = 0;
end

if ~exist('saveEPSFlag','var')
    saveEPSFlag = 0; % do not save EPS file
end

if ~exist(savedFilePath,'dir')
    mkdir(savedFilePath);
end

% save and delte previously saved figures
if deleteOldResultFlag == 1
    deleteOldFigure(savedFilePath);
    
    %{
    currOldFolderName = [savedFilePath,'\oldVersion'];
    if exist(currOldFolderName,'dir')
        % delte all figures in current file
        oldFigName = dir([currOldFolderName,'\*.tiff']);
        
        for figIndex = 1:length(oldFigName)
            currFigName = oldFigName(figIndex).name;
            currFigName = [currOldFolderName,'\',currFigName];
            delete(currFigName);
        end
    else
        mkdir(currOldFolderName);
    end
    
    % more previously saved figures to a folder named 'oldVersion'
    oldFigName = dir([savedFilePath,'\*.tiff']);
    
    for figIndex = 1:length(oldFigName)
        currFigName = oldFigName(figIndex).name;
        currFigName = [savedFilePath,'\',currFigName];
        
        movefile(currFigName,currOldFolderName,'f')
    end
    %}
end

% save figures
for figIndex = 1:allFigCount
    % get figure name
    currFigName = allFigName{figIndex};
    if addFigIDFlag == 1
        currFigID = startFigID+figIndex;
        currFigName = [sprintf('%03d',currFigID),'_',currFigName];
    end
    
    % modify figure name
    invalidStringPos = strfind(currFigName,'|');
    currFigName(invalidStringPos) = '_';
    
    invalidStringPos = strfind(currFigName,'/');
    currFigName(invalidStringPos) = '_';
    
    if isempty(currFigName)
        continue;
    end
    
    % get figure handle
    if ~exist('allFigHandle','var')
        currHandle = figure(figIndex);
    else
        currHandle = allFigHandle(figIndex);
    end
    set(currHandle, 'position', get(0,'ScreenSize'));
    set(currHandle,'Color','White');
    set(currHandle,'renderer','zbuffer');
    
    % save tiff file
    currFileName = [savedFilePath,'\',currFigName,'.tiff']; % modified on 2019-11-18
    
    % task bar may be shown
    fs = getframe(currHandle); % masked on 2022-08-30
    imwrite(fs.cdata,currFileName,'tiff'); % masked on 2022-08-30
    
    %{
    % task bar will not be shown, but saved figures are too large in disk
    size
    set(currHandle, 'InvertHardCopy', 'off');
    print(currHandle,'-dtiffn',currFileName);
    %}
    
    if saveEPSFlag == 1
        % save eps file
        set(currHandle, 'InvertHardCopy', 'off'); % added on 2023-04-28
        set(currHandle,'renderer','painter');
        
        currFilePath_eps = [savedFilePath,'\EPS'];
        if ~exist(currFilePath_eps,'dir')
            mkdir(currFilePath_eps);
        end
        
        currFileName = [currFilePath_eps,'\',currFigName,'.eps']; % modified on 2019-11-18
        
        print(currHandle,'-depsc',currFileName);
    end
    
    % close figure
    close(currHandle);
end

end
