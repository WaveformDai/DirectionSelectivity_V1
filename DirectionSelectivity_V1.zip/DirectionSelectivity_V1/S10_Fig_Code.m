% this funtion aims to show results in S10 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S10_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing results
fontSize = 15;
lineWidth = 3;
dotSize = 8; % size for each sata point
markerSize = 15; % size for indicating significance

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S10 Fig';
figureHandle(figureCount) = figure(figureCount);

% pre-define some parameters
depthBoundary = [ ...
    0, ...
    0.3500, ...
    0.5800, ...
    0.7600, ....
    1.0000, ...
    ];

allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

shownLayerPairName = { ...
    'L4 to L2/3', ...
    'L4 to L4', ...
    'L4 to L5', ...
    'L2/3 to L5', ...
    };

referenceConditionName = { ...
    'nullDir', ...
    'prefDir', ...
    'prefDir', ...
    };
targetConditionName = { ...
    'blank', ...
    'blank', ...
    'nullDir', ...
    };

% parameters for showing results
figColNum = 4;
figRowNum = 4;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.05; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

for shownLayerPairIndex = 1:length(shownLayerPairName)
    currLayerPairName = shownLayerPairName{shownLayerPairIndex};
    
    % get data
    switch currLayerPairName
        case 'L4 to L2/3'
            [allData,~,~] = xlsread(fullFileName,'S10 Fig L4toL23');
        case 'L4 to L4'
            [allData,~,~] = xlsread(fullFileName,'S10 Fig L4toL4');
        case 'L4 to L5'
            [allData,~,~] = xlsread(fullFileName,'S10 Fig L4toL5');
        case 'L2/3 to L5'
            [allData,~,~] = xlsread(fullFileName,'S10 Fig L23toL5');
    end
    
    % allocate data
    currGCVal_blank = allData(:,1);
    currGCVal_nullDir = allData(:,2);
    currGCVal_prefDir = allData(:,3);
    
    % get range for showing results
    currMin = min([currGCVal_blank(:);currGCVal_nullDir(:);currGCVal_prefDir(:)]);
    currMax = max([currGCVal_blank(:);currGCVal_nullDir(:);currGCVal_prefDir(:)]);
    currMin = currMin*(1-0.05*sign(currMin));
    currMax = currMax*(1+0.05*sign(currMax));
    currMin = min(currMin,0);
    currRange = currMax-currMin;
    
    for conditionIndex = 1:length(referenceConditionName)
        currReferenceConditionName = referenceConditionName{conditionIndex};
        currTargetConditionName = targetConditionName{conditionIndex};
        
        % get data
        cmd = ['currGCVal_reference = currGCVal_',currReferenceConditionName,';'];
        eval(cmd);
        
        cmd = ['currGCVal_target = currGCVal_',currTargetConditionName,';'];
        eval(cmd);
        
        % get statistics
        [currCoef_pair_coef,currPVal_pair_coef] = corr(currGCVal_reference,currGCVal_target,'type','Spearman');
        
        currPVal_pair_signrank = signrank(currGCVal_reference,currGCVal_target);
        
        % do Bonferroni correction on p-val
        currPVal_pair_coef = currPVal_pair_coef*(length(allLayerLabel)-1).^2;
        currPVal_pair_signrank = currPVal_pair_signrank*(length(allLayerLabel)-1).^2;
        currPVal_pair_signrank(currPVal_pair_signrank > 1) = 1;
        
        % get position for showing statistics
        textXPos = currMin-currRange*0.1;
        textYPos_signrank = currMin+currRange*1.05;
        textYPos_pair = currMin+currRange*1.15;
        
        textString = sprintf('N=%d,Difference:p=%.3g', ...
            length(currGCVal_reference),currPVal_pair_signrank);
        
        currShownColor = 'k';
        
        % create axis
        figRowIndex = conditionIndex;
        figColIndex = shownLayerPairIndex;
        currLeftPos = leftPos(figColIndex);
        currBotPos = botPos(figRowIndex)-(figRowIndex-1)*0.05;
        currWidth = subFigWidth;
        currHeight = subFigHeight;
        subplot('position',[currLeftPos currBotPos currWidth currHeight])
        plot(currGCVal_reference,currGCVal_target,'o','MarkerEdgeColor','k','MarkerFaceColor','k')
        hold on;
        plot([currMin currMax],[currMin currMax],'k-.')
        text(textXPos,textYPos_signrank,textString,'FontSize',fontSize,'Color',currShownColor)
        if figRowIndex == 1
            text(textXPos,textYPos_pair,currLayerPairName,'FontSize',fontSize,'Color',currShownColor)
        end
        xlim([currMin currMax])
        ylim([currMin currMax])
        xlabel(['GC@',currReferenceConditionName],'FontSize',fontSize)
        ylabel(['GC@',currTargetConditionName],'FontSize',fontSize)
        axis square;
        
        set(gca,'FontSize',fontSize)
        box off;
    end
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);
