% this funtion aims to show results in Fig 1B for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig1_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig1B';
figureHandle(figureCount) = figure(figureCount);

%% show results for left half of Fig 1B
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 1B_Left');

% get positions for showing result
figColNum = 4;
figRowNum = 3;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.225; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.1; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get time info
timePoint = allData(:,1);

% show example result in L2/3 and L4, respectively
shownLayerName = {'L2/3','L4'};
shownLayerColor = {'b','r'};

for layerIndex = 1:length(shownLayerName)
    currShownLayerName = shownLayerName{layerIndex};
    currShownLayerColor = shownLayerColor{layerIndex};
    
    % get data
    switch currShownLayerName
        case 'L2/3'
            currResp = allData(:,2);
            currLatencyIndex = allData(1,4);
            currLatency = allData(1,6);
        case 'L4'
            currResp = allData(:,3);
            currLatencyIndex = allData(1,5);
            currLatency = allData(1,7);
    end
    
    % get range for showing results
    currXMin = timePoint(1);
    currXMax = timePoint(end);
    
    currYMin = min([currResp(:)]);
    currYMax = max([currResp(:)]);
    currYMin = currYMin*(1-0.05*sign(currYMin));
    currYMin = min(currYMin,0);
    currYRange = currYMax-currYMin;
    
    currYMax = currYMin+1.1*currYRange;
    
    % parameters for showing results
    xxTickPos = [-50 0 100 200];
    xxTickLabel = [-50 0 100 200];
    
    textXPos = timePoint(1);
    textYPos = currYMin+1.2*currYRange;
    
    currString = sprintf('%s,Latency:%.2f(ms)',currShownLayerName,currLatency);
    
    % show results
    figRowIndex = layerIndex;
    figColIndex = 1;
    tempLeftPos = leftPos(figColIndex);
    tempBotPos = botPos(figRowIndex);
    tempWidth = subFigWidth;
    tempHeight = subFigHeight;
    subplot('position',[tempLeftPos tempBotPos tempWidth tempHeight])
    plot(timePoint,currResp,'-','Color',currShownLayerColor,'LineWidth',lineWidth)
    hold on;
    plot([0 0],[currYMin currYMax],'k-.','LineWidth',lineWidth)
    plot([currXMin currXMax],[0 0],'k-.','LineWidth',lineWidth)
    plot(timePoint(currLatencyIndex),currResp(currLatencyIndex),'o', ...
        'MarkerSize',markerSize,'MarkerEdgeColor','k','MarkerFaceColor','k')
    text(textXPos,textYPos,currString,'Color',currShownLayerColor,'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)
    xlabel('Time(ms)','FontSize',fontSize)
    ylabel('Response (spk/s)','FontSize',fontSize);
    
    set(gca,'fontsize',fontSize)
    box off;
end

%% show results for right half of Fig 1B
% get data
[allData,~,~] = xlsread(fullFileName,'Fig 1B_Right');

% get stim info
dirNum = 18;
currDir = allData(1:dirNum,1); % in degree

fitDirNum = 360;
currFitDir = allData(1:fitDirNum,8); % in degree

% show example result in L2/3 and L4, respectively
shownLayerName = {'L2/3','L4'};
shownLayerColor = {'b','r'};

for layerIndex = 1:length(shownLayerName)
    currShownLayerName = shownLayerName{layerIndex};
    currShownLayerColor = shownLayerColor{layerIndex};
    
    % get data
    switch currShownLayerName
        case 'L2/3'
            currF0_blank = allData(1,6);
            
            currF0_mean = allData(1:dirNum,2); % dirNum*1
            currF0_ste = allData(1:dirNum,3); % dirNum*1
            
            currFitResp_dir = allData(1:fitDirNum,9); % dirNum*1
            curDSI = allData(1,11);
            currPrefDir = allData(1,13);
        case 'L4'
            currF0_blank = allData(1,7);
            
            currF0_mean = allData(1:dirNum,4); % dirNum*1
            currF0_ste = allData(1:dirNum,5); % dirNum*1
            
            currFitResp_dir = allData(1:fitDirNum,10); % dirNum*1
            curDSI = allData(1,12);
            currPrefDir = allData(1,14);
    end
    
    % get range for showing results
    xxTickPos = 0:50:350;
    xxTickLabel = 0:50:350;
    
    currXMin = currFitDir(1);
    currXMax = currFitDir(end);
    
    currYMin = 0;
    currYMax = max([currF0_mean(:)+currF0_ste(:);currFitResp_dir(:)]);
    currYMax = currYMax*(1+0.05*sign(currYMax));
    currYRange = currYMax-currYMin;
    
    currYMax = currYMin+1.1*currYRange;
    
    textXPos = currXMin;
    textYPos = currYMin+1.2*currYRange;
    
    currString = sprintf('%s,DSI=%.2f:prefDir=%.2f',currShownLayerName,curDSI,currPrefDir);
    
    % show dir tuning
    figRowIndex = layerIndex;
    figColIndex = 3;
    currBotPos = botPos(figRowIndex);
    currLeftPos = leftPos(figColIndex);
    subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight])
    errorbar(currDir,currF0_mean,currF0_ste,'o', ...
        'Color',currShownLayerColor,'MarkerEdgeColor',currShownLayerColor,'MarkerFaceColor',currShownLayerColor)
    hold on;
    plot(currFitDir,currFitResp_dir,'k-','LineWidth',lineWidth)
    plot(currPrefDir+[0 0],[currYMin currYMax],'k-.')
    plot([currXMin currXMax],currF0_blank+[0 0],'k-.')
    text(textXPos,textYPos,currString,'Color',currShownLayerColor,'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    set(gca,'XTick',xxTickPos,'XTickLabel',xxTickLabel)
    xlabel('Direction','FontSize',fontSize)
    ylabel('Response(Spk/sec)','FontSize',fontSize)
    
    set(gca,'fontsize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);