% this funtion aims to show results in S11 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S11_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some parameter
patchSaturation = 0.33; % saturation for patch of shaded errorbar
binNum = 21; % parameters for showing histogram

depthBoundary = [ ...
    0, ...
    0.3500, ...
    0.5800, ...
    0.7600, ....
    1.0000, ...
    ];

allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

layerID_output = [1 3];
layerID_input = [2 4];

shownLayerID = { ...
    layerID_output, ... % L2/3 & L5
    layerID_input, ... % L4 & L6
    };

shownLayerName = { ...
    'Output Layer', ...
    'Input Layer', ...
    };

shownLayerColor = { ...
    'b', ... % L23/output layer
    'r', ... % L4/input layer
    };

currShownLayerNum = 2;

currDepthMin = 0;
currDepthMax = 1;

withReferenceDataFlag = 1;
inputReferenceData = 1;

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

%% show results for S11AB Fig
% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S11AB Fig';
figureHandle(figureCount) = figure(figureCount);

% get data
[allData,~,~] = xlsread(fullFileName,'S11AB Fig');

% allocate data
pooledExpID = allData(:,1);
pooledDepth = allData(:,2);
pooledLayerID = allData(:,3);

pooledData = allData(:,4);

% get range for data
currDataMin = 0;
currDataMax = 2;

pooledData(pooledData < currDataMin) = currDataMin;
pooledData(pooledData > currDataMax) = currDataMax;

% get index for electrode located in input layer or output layer
pooledElecIndex_input = [];
for layerIndex = 1:length(layerID_input)
    currLayerID = layerID_input(layerIndex);
    currElecIndex = find(pooledLayerID == currLayerID);
    
    pooledElecIndex_input = [pooledElecIndex_input;currElecIndex(:)];
end

pooledElecIndex_output = [];
for layerIndex = 1:length(layerID_output)
    currLayerID = layerID_output(layerIndex);
    currElecIndex = find(pooledLayerID == currLayerID);
    
    pooledElecIndex_output = [pooledElecIndex_output;currElecIndex(:)];
end

%% get running median
% pre-define parameters for binning
minWithinBinNum = 5;
minWithinBinNum_norm = 1;
runningSlideDepth = 0.02*currDepthMax;
runningGapDepth = 0.1;

% calculate running median
runningDepth_lower = currDepthMin:runningSlideDepth:currDepthMax;
runningDepth_upper = runningDepth_lower+runningGapDepth;
runningDepth_mid = (runningDepth_lower+runningDepth_upper)/2;

runningData_median = zeros(length(runningDepth_lower),1);
runningData_std = zeros(length(runningDepth_lower),1);
runningData_ste = zeros(length(runningDepth_lower),1);

allWithBinNum = zeros(length(runningDepth_lower),1);

for depthIndex = 1:length(runningDepth_lower)
    % get range for current bin
    currRunningDepth_lower = runningDepth_lower(depthIndex);
    currRunningDepth_upper = runningDepth_upper(depthIndex);
    
    % get index for data within bin
    withinBinIndex = find(pooledDepth <= currRunningDepth_upper & pooledDepth > currRunningDepth_lower);
    withBinNum = length(withinBinIndex);
    allWithBinNum(depthIndex) = withBinNum;
    if withBinNum == 0
        continue;
    end
    
    currData = pooledData(withinBinIndex);
    
    currData_median = median(currData);
    currData_std = std(currData);
    currData_ste = currData_std./sqrt(length(withinBinIndex));
    
    runningData_median(depthIndex) = currData_median;
    runningData_std(depthIndex) = currData_std;
    runningData_ste(depthIndex) = currData_ste;
end

% remove data with invalid bin
invalidBinIndex = find(allWithBinNum < minWithinBinNum);

runningDepth_lower(invalidBinIndex) = [];
runningDepth_upper(invalidBinIndex) = [];
runningDepth_mid(invalidBinIndex) = [];

runningData_median(invalidBinIndex) = [];
runningData_std(invalidBinIndex) = [];
runningData_ste(invalidBinIndex) = [];

%% show data and running median at different layer
% parameters for showing results
figColNum = 4;
figRowNum = 3;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.45; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.05; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% get position for showing layer info
allXTickPos = zeros(length(depthBoundary)-1,1);
allXTickLabel = cell(length(depthBoundary)-1,1);
for boundaryIndex = 1:(length(depthBoundary)-1)
    currBoundary_lower = depthBoundary(boundaryIndex);
    currBoundary_upper = depthBoundary(boundaryIndex+1);
    
    currYTickPos = (currBoundary_lower+currBoundary_upper)/2;
    currYTickLabel = ['L',allLayerLabel{boundaryIndex}];
    
    allXTickPos(boundaryIndex) = currYTickPos;
    allXTickLabel{boundaryIndex} = currYTickLabel;
end

% get range for showing data
currYMin = currDataMin;
currYMax = currDataMax;

currXMin = currDepthMin;
currXMax = currDepthMax;

currTuningVarName = 'F1/F0';

% show figure in given figure handle
figRowIndex = 1;
figColIndex = 1;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currWidth = subFigWidth;
currHeight = subFigHeight*figRowNum+rowGap*(figRowNum-1);
subplot('position',[currLeftPos currBotPos currWidth currHeight])
% if ~isempty(runningDepth_mid)
if length(runningDepth_mid) > 1
    currHandle = shadedErrorBar(runningDepth_mid,runningData_median,runningData_ste, ...
        'patchSaturation',patchSaturation);
    set(currHandle.mainLine,'Color','k','LineWidth',lineWidth)
    set(currHandle.patch,'FaceColor',0.5+[0 0 0])
    set(currHandle.edge(1),'Color','none','LineWidth',lineWidth/2)
    set(currHandle.edge(2),'Color','none','LineWidth',lineWidth/2)
end
hold on;
plot(pooledDepth(pooledElecIndex_input),pooledData(pooledElecIndex_input),'o', ...
    'MarkerEdgeColor','r','MarkerFaceColor','r')
hold on;
plot(pooledDepth(pooledElecIndex_output),pooledData(pooledElecIndex_output),'o', ...
    'MarkerEdgeColor','b','MarkerFaceColor','b')

for boundaryIndex = 1:length(depthBoundary)
    currBoundary = depthBoundary(boundaryIndex);
    plot(currBoundary+[0 0],[currYMin currYMax],'k-.')
end

if withReferenceDataFlag == 1
    plot([currXMin currXMax],inputReferenceData+[0 0],'k-.')
end

set(gca,'XTick',allXTickPos)
set(gca,'XTickLabel',allXTickLabel,'FontSize',fontSize)
xlim([currXMin currXMax])
ylim([currYMin currYMax])
ylabel(currTuningVarName,'FontSize',fontSize)
view(90,90)

set(gca,'FontSize',fontSize)
box off;

%% show direct comparison of data between L4 and L23 or between input layer and output layer
% parameters for showing results
figRowNum = 2;
figColNum = 2;

% get position for showing results
leftGap = leftPos(1)+subFigWidth+0.05; % gap from left edge
rightGap = 1-leftPos(end)+0.05; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.18; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

leftPos = leftPos-leftPos(1)+0.05;
leftPos(3) = leftPos(2)+subFigWidth+columnGap;

% get index for electrodes in given layer
currElecIndex_reference = pooledElecIndex_input;
currElecIndex_target = pooledElecIndex_output;

layerName_reference = shownLayerName{2};
layerName_target = shownLayerName{1};

currXLabel = [layerName_reference];
currYLabel = [layerName_target];

% get experiment ID for each site
uniqueExpID = unique(pooledExpID);
uniqueExpNum = length(uniqueExpID);

% initialize data for L4/input layer and L23/output layer
pooledData_reference_median = [];
pooledData_target_median = [];

pooledData_reference_ste = [];
pooledData_target_ste = [];

pooledExpID_pair = [];

% get data for input layer and output layer for each
% unit
for uniqueExpIndex = 1:uniqueExpNum
    tempExpID = uniqueExpID(uniqueExpIndex);
    
    % get data
    tempElecIndex = find(pooledExpID == tempExpID);
    
    tempElecIndex_reference = intersect(tempElecIndex,currElecIndex_reference);
    tempElecIndex_target = intersect(tempElecIndex,currElecIndex_target);
    
    if ~isempty(tempElecIndex_reference) && ...
            ~isempty(tempElecIndex_target)
        % get data
        tempData_reference = pooledData(tempElecIndex_reference);
        tempData_target = pooledData(tempElecIndex_target);
        
        % get statistics
        tempData_reference_median = median(tempData_reference);
        tempData_target_median = median(tempData_target);
        
        tempData_reference_std = std(tempData_reference);
        tempData_target_std = std(tempData_target);
        
        tempData_reference_ste = tempData_reference_std./sqrt(length(tempData_reference));
        tempData_target_ste = tempData_target_std./sqrt(length(tempData_target));
        
        % pool data
        pooledData_reference_median = [pooledData_reference_median(:);tempData_reference_median(:)];
        pooledData_target_median = [pooledData_target_median(:);tempData_target_median(:)];
        
        pooledData_reference_ste = [pooledData_reference_ste(:);tempData_reference_ste(:)];
        pooledData_target_ste = [pooledData_target_ste(:);tempData_target_ste(:)];
        
        pooledExpID_pair = [pooledExpID_pair(:);tempExpID];
    end
end

if isempty(pooledData_reference_median)
    pooledData_reference_median = currDataMin;
    pooledData_target_median = currDataMin;
    
    pooledData_reference_ste = 0;
    pooledData_target_ste = 0;
end

% get statistics
[currCoef_pair_coef,currPVal_pair_coef] = corr(pooledData_reference_median,pooledData_target_median,'type','Spearman');

currPVal_pair_signrank = signrank(pooledData_reference_median,pooledData_target_median);

% do linear fitting
fitXX_data = [currDataMin,currDataMax];

currFitCoef = polyfit(pooledData_reference_median,pooledData_target_median,1);
currFitYY = currFitCoef*[fitXX_data;1,1];

%% get distribution/cumulative distribution of response properties in each layer
% get data to be shown
currPooledLayerID = pooledLayerID;
currPooledData = pooledData;

% get bin for statistics
currEdge_data = linspace(currDataMin,currDataMax,binNum);

currEdgeDiff_data = (currEdge_data(2)-currEdge_data(1))/2;
currShownEdge_data = currEdge_data+currEdgeDiff_data;
currShownEdge_data = currShownEdge_data(1:(end-1));

% initialize histogram and statistics
allHist_data = zeros(currShownLayerNum,binNum-1);
allCumDistribution_data = zeros(currShownLayerNum,binNum-1);
allElecNum_data = zeros(currShownLayerNum,1);

allMedian_data = zeros(currShownLayerNum,1);
allMean_data = zeros(currShownLayerNum,1);
allStd_data = zeros(currShownLayerNum,1);
allSte_data = zeros(currShownLayerNum,1);

allPVal_median_withinLayer_signtest = zeros(currShownLayerNum,1); % compare median value with reference data for each layer, will not be used
allPVal_median_withinLayer_ranksum = zeros(currShownLayerNum,1); % compare median value with reference data for each layer, will not be used

allPairData = cell(currShownLayerNum,1);

% get histogram and statistics
for layerIndex = 1:currShownLayerNum
    currShownLayerID = shownLayerID{layerIndex};
    
    % get data
    currValidElecIndex = [];
    for idIndex = 1:length(currShownLayerID)
        tempShownLayerID = currShownLayerID(idIndex);
        tempValidElecIndex = find(currPooledLayerID == tempShownLayerID);
        currValidElecIndex = [currValidElecIndex(:);tempValidElecIndex(:)];
    end
    currData = currPooledData(currValidElecIndex);
    
    % get histogram
    currHist_data = histcounts(currData,currEdge_data);
    currHist_data = currHist_data./sum(currHist_data);
    
    % get cumulative distribution
    currCumDistribution_data = cumsum(currHist_data);
    
    % get statistics
    currMedian_data = median(currData);
    currMean_data = mean(currData);
    currStd_data = std(currData);
    currSte_data = currStd_data./sqrt(length(currData));
    
    % do sign test
    currPVal_signtest = signtest(currData,inputReferenceData);
    currPVal_ranksum = ranksum(currData,inputReferenceData);
    
    % pool data
    allHist_data(layerIndex,:) = currHist_data;
    allCumDistribution_data(layerIndex,:) = currCumDistribution_data;
    allElecNum_data(layerIndex) = length(currData);
    
    allMedian_data(layerIndex) = currMedian_data;
    allMean_data(layerIndex) = currMean_data;
    allStd_data(layerIndex) = currStd_data;
    allSte_data(layerIndex) = currSte_data;
    
    allPVal_median_withinLayer_signtest(layerIndex) = currPVal_signtest;
    allPVal_median_withinLayer_ranksum(layerIndex) = currPVal_ranksum;
    
    allPairData{layerIndex} = currData;
end

% get statistical comparison of median value
if sum(isnan(allPairData{1})) == length(allPairData{1}) || ...
        sum(isnan(allPairData{2})) == length(allPairData{2})
    currPVal_median_acrossLayer_ranksum = 1; % compare median value across layers
    currPVal_median_acrossLayer_kstest = 1; % compare distribution across layers, will not used
else
    currPVal_median_acrossLayer_ranksum = ranksum(allPairData{1},allPairData{2}); % compare median value across layers
    [~,currPVal_median_acrossLayer_kstest] = kstest2(allPairData{1},allPairData{2},'Tail','larger'); % compare distribution across layers, will not used
end

%% show distribution/cumulative distribution of response properties at different layers
% get range for showing results
currXLabel = currTuningVarName;

currXMin = currEdge_data(1);
currXMax = currEdge_data(end);
currXRange = currXMax-currXMin;

currYMin = 0;
currYMax = 1;
currYRange = currYMax-currYMin;

% pre-define position for showing and comparing median
currYPos_marker_median = currYMin+currYRange*1.03; % position for showing median and ste

currYPos_line_median = currYMin+currYRange*1.06; % position for horizontal lines connecting two medians

currXPos_pval_median = mean(allMedian_data);
currYPos_pval_median = currYMin+currYRange*1.08; % position for showing significance

currYMax = currYMin+currYRange*1.1;

% show histogram and statistics
allLegendHandle = zeros(currShownLayerNum,1);

figRowIndex = 1;
figColIndex = 2;
currLeftPos = leftPos(figColIndex);
currBotPos = botPos(figRowIndex);
currWidth = subFigWidth;
currHeight = subFigHeight;
subplot('position',[currLeftPos currBotPos currWidth currHeight])
hold on;
for layerIndex = 1:currShownLayerNum
    currShownLayerColor = shownLayerColor{layerIndex};
    
    % get data
    currCumDistribution_data = allCumDistribution_data(layerIndex,:);
    
    % get median value
    currMedian_data = allMedian_data(layerIndex);
    currMean_data = allMean_data(layerIndex);
    currStd_data = allStd_data(layerIndex);
    currSte_data = allSte_data(layerIndex);
    
    % show cumulative distribution
    currLegendHandle = plot(currShownEdge_data,currCumDistribution_data,'-','Color',currShownLayerColor,'LineWidth',lineWidth);
    allLegendHandle(layerIndex) = currLegendHandle;
    
    % show median value
    errorbar(currMedian_data,currYPos_marker_median,currSte_data, ...
        '-','horizontal','Color',currShownLayerColor)
    plot(currMedian_data,currYPos_marker_median,'o', ...
        'MarkerEdgeColor',currShownLayerColor,'MarkerFaceColor',currShownLayerColor)
end
if withReferenceDataFlag == 1
    plot(inputReferenceData+[0 0],[currYMin currYMax],'k-.')
end
plot([currXMin currXMax],0.5+[0 0],'k-.')

% show significance of median across layers
if currPVal_median_acrossLayer_ranksum < 0.001
    currMarker = '***';
elseif currPVal_median_acrossLayer_ranksum < 0.01
    currMarker = '**';
elseif currPVal_median_acrossLayer_ranksum < 0.05
    currMarker = '*';
else
    currMarker = 'ns';
end
plot(allMedian_data,currYPos_line_median+[0 0],'k-','LineWidth',lineWidth)
text(currXPos_pval_median,currYPos_pval_median,currMarker,'Color','k','FontSize',fontSize,'HorizontalAlignment','center')

% add legend
currLegendHandle = legend(allLegendHandle,shownLayerName,'location','southeast');
set(currLegendHandle,'fontsize',fontSize)

xlim([currXMin currXMax])
ylim([currYMin currYMax])
xlabel(currXLabel,'FontSize',fontSize)
ylabel('Proportion','FontSize',fontSize)

set(gca,'YColor','k')

axis square;
set(gca,'FontSize',fontSize)
box off;

%% show results for S11C-H Fig
% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S11C_H Fig';
figureHandle(figureCount) = figure(figureCount);

% get data
[allData,~,~] = xlsread(fullFileName,'S11C-H Fig');

% allocate data
currValidLayerID = allData(:,1);
currValidRFValue = allData(:,2);
currValidTuningValue = allData(:,3);

% pre-define some parameters
rfMinValue = 0;
rfMaxValue = 2;

tuningMinValue = 0;
tuningMaxValue = 1;

% get position for showing results
figRowNum = 4;
figColNum = 4;

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.03; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% show data in chosen layer
for layerIndex = 1:length(shownLayerID)
    currLayerID = shownLayerID{layerIndex};
    currLayerName = shownLayerName{layerIndex};
    
    currLayerEdgeColor = shownLayerColor{layerIndex};
    currLayerFaceColor = shownLayerColor{layerIndex};
    
    % initialize data to be shown
    currShownRFValue = [];
    currShownTuningValue = [];
    
    % show results
    figRowIndex = figRowNum;
    figColIndex = layerIndex;
    currBotPos = botPos(figRowIndex);
    currLeftPos = leftPos(figColIndex);
    
    for tempLayerIndex = 1:length(currLayerID)
        tempLayerID = currLayerID(tempLayerIndex);
        
        % get data in chosen layer
        tempElecIndex = find(currValidLayerID == tempLayerID);
        tempShownRFValue = currValidRFValue(tempElecIndex);
        tempShownTuningValue = currValidTuningValue(tempElecIndex);
        
        % pool data
        currShownRFValue = [currShownRFValue;tempShownRFValue(:)];
        currShownTuningValue = [currShownTuningValue;tempShownTuningValue(:)];
        
        % show relationship bewteen simpleness and tuning
        subplot('position',[currLeftPos currBotPos subFigWidth subFigHeight]);
        hold on;
        plot(tempShownRFValue,tempShownTuningValue,'o','MarkerSize',markerSize, ...
            'MarkerFaceColor',currLayerFaceColor,'MarkerEdgeColor',currLayerEdgeColor)
    end
    
    % get correlation and stattistics
    [currCoef,currPVal] = corr(currShownRFValue,currShownTuningValue,'type','Spearman');
    if numel(currPVal) > 1
        currPVal = currPVal(2);
    end
    
    % get range for showing results
    currXMin = rfMinValue*(1-0.05*sign(rfMinValue));
    currXMax = rfMaxValue*(1+0.05*sign(rfMaxValue));
    currXRange = currXMax-currXMin;
    
    textXPos = currXMin+currXRange*0.05;
    
    currYMin = tuningMinValue;
    currYMax = tuningMaxValue*1.1;
    currYRange = currYMax-currYMin;
    
    textYPos = currYMin+currYRange*1.05;
    
    % get linear fitting
    currFitCoef = polyfit(currShownRFValue,currShownTuningValue,1);
    currFitXX = [currXMin,currXMax];
    currFitYY = currFitCoef*[currFitXX;1,1];
    
    % modify axis
    plot(currFitXX,currFitYY,'k-','LineWidth',lineWidth)
    text(textXPos,textYPos,sprintf('%s:N=%d,r=%.3f,p=%0.3g',currLayerName,length(currShownRFValue),currCoef,currPVal),'FontSize',fontSize)
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel('F1/F0','fontsize',fontSize)
    ylabel('DSI','fontsize',fontSize)
end

%% show comparison of distribution between simple cell and complex cell
referenceDataType = { ...
    'SC_Input', ... % simple cell in input layer
    'CC_Input', ... % complex cell in input layer
    'SC_Output', ... % simple cell in output layer
    'SC_Input', ... % simple cell in input layer
    };
targetDataType = { ...
    'SC_Output', ... % simple cell in output layer
    'CC_Output', ... % complex cell in output layer
    'CC_Output', ... % complex cell in output layer
    'CC_Input', ... % complex cell in input layer
    };

for dataTypeIndex = 1:length(referenceDataType)
    currReferenceDataType = referenceDataType{dataTypeIndex};
    currTargetDataType = targetDataType{dataTypeIndex};
    
    % get index for simple cell/complex cell
    if contains(currReferenceDataType,'SC')
        currIndex_cellType_reference = find(currValidRFValue >= 1);
        currLine_cellType_reference = '-';
    else
        currIndex_cellType_reference = find(currValidRFValue < 1);
        currLine_cellType_reference = '-.';
    end
    
    if contains(currTargetDataType,'SC')
        currIndex_cellType_target = find(currValidRFValue >= 1);
        currLine_cellType_target = '-';
    else
        currIndex_cellType_target = find(currValidRFValue < 1);
        currLine_cellType_target = '-.';
    end
    
    % get index for electrodes in each layer
    if contains(currReferenceDataType,'Input')
        currLayerID_reference = layerID_input;
        currColor_layer_reference = 'r';
    elseif contains(currReferenceDataType,'Output')
        currLayerID_reference = layerID_output;
        currColor_layer_reference = 'b';
    else
        currLayerID_reference = [layerID_output,layerID_input];
        currColor_layer_reference = 'k';
    end
    
    if contains(currTargetDataType,'Input')
        currLayerID_target= layerID_input;
        currColor_layer_target = 'r';
    elseif contains(currTargetDataType,'Output')
        currLayerID_target= layerID_output;
        currColor_layer_target = 'b';
    else
        currLayerID_target= [layerID_output,layerID_input];
        currColor_layer_target = 'k';
    end
    
    currIndex_layer_reference = [];
    for layerIndex = 1:length(currLayerID_reference)
        tempLayerID = currLayerID_reference(layerIndex);
        tempElecIndex = find(currValidLayerID == tempLayerID);
        currIndex_layer_reference = [currIndex_layer_reference;tempElecIndex(:)];
    end
    
    currIndex_layer_target = [];
    for layerIndex = 1:length(currLayerID_target)
        tempLayerID = currLayerID_target(layerIndex);
        tempElecIndex = find(currValidLayerID == tempLayerID);
        currIndex_layer_target = [currIndex_layer_target;tempElecIndex(:)];
    end
    
    % get data
    currIndex_reference = intersect(currIndex_cellType_reference,currIndex_layer_reference);
    currIndex_target = intersect(currIndex_cellType_target,currIndex_layer_target);
    
    currData_reference = currValidTuningValue(currIndex_reference);
    currData_target = currValidTuningValue(currIndex_target);
    
    % get statistics
    currData_reference_mean = mean(currData_reference);
    currData_target_mean = mean(currData_target);
    
    currData_reference_median = median(currData_reference);
    currData_target_median = median(currData_target);
    
    currData_reference_std = std(currData_reference);
    currData_target_std = std(currData_target);
    
    currData_reference_ste = currData_reference_std./sqrt(length(currData_reference));
    currData_target_ste = currData_target_std./sqrt(length(currData_target));
    
    currPVal_median_ranksum = ranksum(currData_reference,currData_target); % compare median value across layers
    
    % get range and bin for histogram
    currMin_data = tuningMinValue;
    currMax_data = tuningMaxValue;
    
    currEdge_data = linspace(currMin_data,currMax_data,11); % 10 bins in Kim & Freeman paper
    
    currEdgeDiff_data = (currEdge_data(2)-currEdge_data(1))/2;
    currShownEdge_data = currEdge_data+currEdgeDiff_data;
    currShownEdge_data = currShownEdge_data(1:(end-1));
    
    % get cumulative distribution
    currHist_reference = histcounts(currData_reference,currEdge_data);
    currHist_reference = currHist_reference./sum(currHist_reference);
    currCumDistribution_reference = cumsum(currHist_reference);
    
    currHist_target = histcounts(currData_target,currEdge_data);
    currHist_target = currHist_target./sum(currHist_target);
    currCumDistribution_target = cumsum(currHist_target);
    
    % pool data
    allCumDistribution_data = [currCumDistribution_reference;currCumDistribution_target];
    allMedian_data = [currData_reference_median,currData_target_median];
    allMean_data = [currData_reference_mean,currData_target_mean];
    allStd_data = [currData_reference_std,currData_target_std];
    allSte_data = [currData_reference_ste,currData_target_ste];
    
    % initialize number of neurons in different ypes
    allTypeCount_data = zeros(2,2);
    
    allPVal_proportion_withinLayer_chi2 = zeros(2,1);
    
    % get number of neurons in different ypes
    for layerIndex = 1:2
        switch layerIndex
            case 1
                currData = currData_reference;
            case 2
                currData = currData_target;
        end
        
        % get number of neurons in different ypes
        currTypeIndex_neg = find(currData < 1/3);
        currTypeIndex_pos = find(currData > 1/3);
        
        currTypeIndex_neg = length(currTypeIndex_neg);
        currTypeIndex_pos = length(currTypeIndex_pos);
        
        % do chi-square test to determine if data are sampled from binomial
        % distribution with p=0.5
        currExpNum = [length(currData)/2 length(currData)/2];
        currBin_chi2 = 1:2;
        [currHypothesis,currPVal,currStat] = chi2gof(currBin_chi2,'Ctrs',currBin_chi2,...
            'Frequency',[currTypeIndex_neg,currTypeIndex_pos], ...
            'Expected',currExpNum...
            );
        %
        % pool data
        allTypeCount_data(layerIndex,:) = [currTypeIndex_neg,currTypeIndex_pos];
        
        allPVal_proportion_withinLayer_chi2(layerIndex,1) = currPVal;
    end
    
    % do chi-square test to determine if data from different layers have the
    % same distribution
    % re-generate false raw data
    [currData_referenceLayer,currData_targetLayer] = inversecrosstab(allTypeCount_data);
    
    % do chi-square test using crosstab
    [currTable,currChi2,currPVal_proportion_acrossLayer_chi2,currLabel] = crosstab(currData_referenceLayer,currData_targetLayer);
    
    % get proportion
    allTypeSum_data = sum(allTypeCount_data,2); % layerNum*1
    allTypeProportion_data = bsxfun(@rdivide,allTypeCount_data,allTypeSum_data);
    
    %% show results
    inputReferenceData = 1/3;
    
    % get range for showing results
    currXLabel = addRightSlash(currTuningVarName);
    
    currXMin = currEdge_data(1);
    currXMax = currEdge_data(end);
    currXRange = currXMax-currXMin;
    
    currYMin = 0;
    currYMax = 1;
    currYRange = currYMax-currYMin;
    
    % pre-define position for showing and comparing median
    currYPos_marker_median = currYMin+currYRange*1.03; % position for showing median and ste
    
    currYPos_line_median = currYMin+currYRange*1.06; % position for horizontal lines connecting two medians
    
    currXPos_pval_median = mean(allMedian_data);
    currYPos_pval_median = currYMin+currYRange*1.1; % position for showing significance
    
    % get y position for showing proportion
    currDiff_reference = abs(currEdge_data-inputReferenceData);
    currBinIndex_reference = find(currDiff_reference == min(currDiff_reference));
    
    allProportion_reference = allCumDistribution_data(:,currBinIndex_reference);
    
    % get x position for showing
    currXPos_marker_arrow_proportion = currXMin+currXRange; % position for showing triangle
    
    currXPos_start_arrow_proportion = currXMin+currXRange*1; % position for lines connecting triangle
    currXPos_stop_arrow_proportion = currXMin+currXRange*1.08; % position for lines connecting triangle
    
    currXPos_line_proportion = currXMin+currXRange*1.10; % position for lines connecting proportions
    
    currXPos_pval_proportion_withinLayer = (currXPos_start_arrow_proportion+currXPos_stop_arrow_proportion)/2;
    
    currXPos_pval_proportion_acrossLayer = currXMin+currXRange*1.12; % position for showing significance
    currYPos_pval_proportion_acrossLayer = mean(allProportion_reference);
    
    % modify x range and y range
    currXMax = currXMin+currXRange*1.15;
    currYMax = currYMin+currYRange*1.15;
    
    % show histogram and statistics
    allLegendHandle = zeros(2,1);
    
    % show results
    figRowIndex = ceil(dataTypeIndex./2)*2;
    currBotPos = botPos(figRowIndex)+0.1;
    
    figColIndex = mod(dataTypeIndex,2);
    if figColIndex == 0
        figColIndex = 2;
    end
    figColIndex = figColIndex+2;
    currLeftPos = leftPos(figColIndex);
    
    subplot('position',[currLeftPos currBotPos subFigWidth*1.2 subFigHeight*1.5]);
    hold on;
    for layerIndex = 1:2
        switch layerIndex
            case 1
                currShownColor = currColor_layer_reference;
                currShownLine = currLine_cellType_reference;
            case 2
                currShownColor = currColor_layer_target;
                currShownLine = currLine_cellType_target;
        end
        
        % get data
        currCumDistribution_data = allCumDistribution_data(layerIndex,:);
        
        % get median value
        currMedian_data = allMedian_data(layerIndex);
        currMean_data = allMean_data(layerIndex);
        currStd_data = allStd_data(layerIndex);
        currSte_data = allSte_data(layerIndex);
        
        % show cumulative distribution
        currLegendHandle = plot(currShownEdge_data,currCumDistribution_data,currShownLine,'Color',currShownColor,'LineWidth',lineWidth);
        allLegendHandle(layerIndex) = currLegendHandle;
        
        % show median value
        errorbar(currMedian_data,currYPos_marker_median,currSte_data, ...
            '-','horizontal','Color',currShownColor)
        switch currShownLine
            case '-'
                plot(currMedian_data,currYPos_marker_median,'o', ...
                    'MarkerEdgeColor',currShownColor,'MarkerFaceColor',currShownColor)
            case '-.'
                plot(currMedian_data,currYPos_marker_median,'o', ...
                    'MarkerEdgeColor',currShownColor,'MarkerFaceColor','none')
        end
        
        % show proportion and significance within each layer
        % get p-val for proportion
        currPVal_proportion_withinLayer_chi2 = allPVal_proportion_withinLayer_chi2(layerIndex);
        
        if currPVal_proportion_withinLayer_chi2 < 0.001
            currMarker = '***';
        elseif currPVal_proportion_withinLayer_chi2 < 0.01
            currMarker = '**';
        elseif currPVal_proportion_withinLayer_chi2 < 0.05
            currMarker = '*';
        else
            currMarker = 'ns';
        end
        
        % get position for proportion and significance
        currYPos_proportion = allProportion_reference(layerIndex);
        if allProportion_reference(1) >= allProportion_reference(2) % the first layer is larger
            currYPos_pval_proportion_withinLayer = currYPos_proportion+0.04*currYRange*(-1).^(layerIndex+1);
        else % the first layer is smaller
            currYPos_pval_proportion_withinLayer = currYPos_proportion+0.04*currYRange*(-1).^(layerIndex);
        end
        
        % show proportion and significance
        plot(currXPos_marker_arrow_proportion,currYPos_proportion,'<','MarkerEdgeColor',currShownColor,'MarkerFaceColor',currShownColor)
        plot([currXPos_start_arrow_proportion currXPos_stop_arrow_proportion],currYPos_proportion+[0 0],'Color',currShownColor,'LineWidth',lineWidth)
        text(currXPos_pval_proportion_withinLayer,currYPos_pval_proportion_withinLayer,currMarker,'Color',currShownColor,'FontSize',fontSize,'HorizontalAlignment','center')
    end
    plot(inputReferenceData+[0 0],[currYMin currYMax],'k-.')
    plot([currXMin currXMax],0.5+[0 0],'k-.')
    
    % show significance of median across layers
    if currPVal_median_ranksum < 0.001
        currMarker = '***';
    elseif currPVal_median_ranksum < 0.01
        currMarker = '**';
    elseif currPVal_median_ranksum < 0.05
        currMarker = '*';
    else
        currMarker = 'ns';
    end
    plot(allMedian_data,currYPos_line_median+[0 0],'k-','LineWidth',lineWidth)
    text(currXPos_pval_median,currYPos_pval_median,currMarker,'Color','k','FontSize',fontSize,'HorizontalAlignment','center')
    
    % show significance of proportion across layers
    if currPVal_proportion_acrossLayer_chi2 < 0.001
        currMarker = '***';
    elseif currPVal_proportion_acrossLayer_chi2 < 0.01
        currMarker = '**';
    elseif currPVal_proportion_acrossLayer_chi2 < 0.05
        currMarker = '*';
    else
        currMarker = 'ns';
    end
    
    plot(currXPos_line_proportion+[0 0],allProportion_reference,'k-','LineWidth',lineWidth)
    text(currXPos_pval_proportion_acrossLayer,currYPos_pval_proportion_acrossLayer,currMarker,'Color','k','FontSize',fontSize,'HorizontalAlignment','left')
    
    % add legend
    currShownLagend = { ...
        addRightSlash(sprintf('%s:N=%d',currReferenceDataType,length(currData_reference))), ...
        addRightSlash(sprintf('%s:N=%d',currTargetDataType,length(currData_target)))};
    currLegendHandle = legend(allLegendHandle,currShownLagend,'location','southeast');
    set(currLegendHandle,'fontsize',fontSize)
    
    xlim([currXMin currXMax])
    ylim([currYMin currYMax])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel('Proportion','FontSize',fontSize)
    
    set(gca,'YColor','k')
    
    axis square;
    set(gca,'FontSize',fontSize)
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);