% this funtion aims to show results in S7 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S7_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S7 Fig';
figureHandle(figureCount) = figure(figureCount);

%% show results for S7 Fig
shownDataTypeName = {'Data','Model'};

for dataTypeIndex = 1:length(shownDataTypeName)
    currShownDataTypeName = shownDataTypeName{dataTypeIndex};
    
    % get data
    switch currShownDataTypeName
        case 'Data'
            [allData,~,~] = xlsread(fullFileName,'S7A Fig');
        case 'Model'
            [allData,~,~] = xlsread(fullFileName,'S7B Fig');
    end
    
    % get data to be shown
    currShownRatio_pref = allData(:,1);
    currShownRatio_null = allData(:,2);
    currShownRatio_blank = allData(:,3);
    
    % pre-define some parameters
    dirPairName_reference = { ...
        'Blank', ...
        'Blank', ...
        'Null Direction', ...
        };
    dirPairName_target = { ...
        'Null Direction', ...
        'Preferred Direction', ...
        'Preferred Direction', ...
        };
    
    dirPairName_reference_brief = { ...
        'blank', ...
        'blank', ...
        'nullDir', ...
        };
    dirPairName_target_brief = { ...
        'nullDir', ...
        'prefDir', ...
        'prefDir', ...
        };
    
    % get range for histogram
    currMin_ratio = min([currShownRatio_blank(:);currShownRatio_null(:);currShownRatio_pref(:)]);
    currMax_ratio = max([currShownRatio_blank(:);currShownRatio_null(:);currShownRatio_pref(:)]);
    currMin_ratio = currMin_ratio*(1-0.05*sign(currMin_ratio));
    currMax_ratio = currMax_ratio*(1+0.05*sign(currMax_ratio));
    currMin_ratio = min(currMin_ratio,0);
    
    for dirPairIndex = 1:length(dirPairName_reference)
        currDirPairName_reference = dirPairName_reference{dirPairIndex};
        currDirPairName_target = dirPairName_target{dirPairIndex};
        
        currDirPairName_reference_brief = dirPairName_reference_brief{dirPairIndex};
        currDirPairName_target_brief = dirPairName_target_brief{dirPairIndex};
        
        % get data
        switch currDirPairName_reference
            case 'Blank'
                currShownRatio_reference = currShownRatio_blank; % pairNum*1
            case 'Null Direction'
                currShownRatio_reference = currShownRatio_null; % pairNum*1
            case 'Preferred Direction'
                currShownRatio_reference = currShownRatio_pref; % pairNum*1
        end
        
        switch currDirPairName_target
            case 'Blank'
                currShownRatio_target = currShownRatio_blank; % pairNum*1
            case 'Null Direction'
                currShownRatio_target = currShownRatio_null; % pairNum*1
            case 'Preferred Direction'
                currShownRatio_target = currShownRatio_pref; % pairNum*1
        end
        
        % get statistics
        [currCoef_pair_coef,currPVal_pair_coef] = corr(currShownRatio_reference,currShownRatio_target,'type','Spearman');
        
        currPVal_pair_signrank = signrank(currShownRatio_reference,currShownRatio_target);
        
        % do linear fitting
        fitXX_data = [currMin_ratio,currMax_ratio];
        
        currFitCoef = polyfit(currShownRatio_reference,currShownRatio_target,1);
        currFitYY = currFitCoef*[fitXX_data;1,1];
        
        currRange = currMax_ratio-currMin_ratio;
        textXPos = currMin_ratio+currRange*0;
        
        textYPos_coef = currMin_ratio+currRange*1.15;
        textYPos_signrank = currMin_ratio+currRange*1.05;
        textYPos_title = currMin_ratio+currRange*0.95;
        
        textString_coef = sprintf('N=%d,r=%.2g,p=%.3g', ...
            length(currShownRatio_reference),currCoef_pair_coef,currPVal_pair_coef);
        textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
        
        currXLabel = addRightSlash(['Response Ratio_',currDirPairName_reference_brief]);
        currYLabel = addRightSlash(['Response Ratio_',currDirPairName_target_brief]);
        
        % show comparison
        figRowIndex = dataTypeIndex*2-1;
        figColIndex = dirPairIndex*2-1;
        currLeftPos = leftPos(figColIndex);
        currBotPos = botPos(figRowIndex)-0.2;
        currWidth = subFigWidth;
        currHeight = subFigHeight;
        subplot('position',[currLeftPos currBotPos currWidth currHeight])
        plot(currShownRatio_reference,currShownRatio_target,'o', ...
            'MarkerEdgeColor','k','MarkerFaceColor','k')
        hold on;
        plot(fitXX_data,currFitYY,'k-','LineWidth',lineWidth)
        plot([currMin_ratio currMax_ratio],[currMin_ratio currMax_ratio],'k-.')
        plot([1 1],[currMin_ratio currMax_ratio],'k-.')
        plot([currMin_ratio currMax_ratio],[1 1],'k-.')
        text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
        text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
        xlim([currMin_ratio currMax_ratio])
        ylim([currMin_ratio currMax_ratio])
        xlabel(currXLabel,'FontSize',fontSize)
        ylabel(currYLabel,'FontSize',fontSize)
        axis square;
        
        set(gca,'FontSize',fontSize)
        box off;
    end
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);