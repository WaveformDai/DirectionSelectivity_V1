% this funtion aims to show results in S6 Fig for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'S6_Fig_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% parameters for showing resutls
fontSize = 15;
lineWidth = 3;
markerSize = 10;

% get position for showing results
figRowNum = 4; % different layer pairs
figColNum = 6; % different direction pairs

leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.05; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.03; % gap between columns
rowGap = 0.04; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'S6 Fig';
figureHandle(figureCount) = figure(figureCount);

%% show results
shownFitQualityName = {'AIC','BIC'};

for fitQualityIndex = 1:length(shownFitQualityName)
    currShownFitQualityName= shownFitQualityName{fitQualityIndex};
    
    % get data
    switch currShownFitQualityName
        case 'AIC'
            [allData,~,~] = xlsread(fullFileName,'S6A Fig');
        case 'BIC Direction'
            [allData,~,~] = xlsread(fullFileName,'S6B Fig');
    end
    
    % allocate data
    currData_untuned = allData(:,1);
    currData_tuned = allData(:,2);
    
    % get statistics
    currPVal_pair_signrank = signrank(currData_untuned,currData_tuned);
    
    % show AIC and BIC in log scale
    currData_tuned = log(currData_tuned);
    currData_untuned = log(currData_untuned);
    
    % get range for shown result
    currMin = min([currData_tuned(:);currData_untuned(:)]);
    currMax = max([currData_tuned(:);currData_untuned(:)]);
    currMin = currMin*(1-0.05*sign(currMin));
    currMax = currMax*(1+0.05*sign(currMax));
    currRange = currMax-currMin;
    
    textXPos = currMin+currRange*0;
    textYPos_coef = currMin+currRange*1.15;
    textYPos_signrank = currMin+currRange*1.05;
    
    textString_coef = sprintf('N=%d', ...
        length(currData_untuned));
    textString_signrank = sprintf('Difference:p=%.3g',currPVal_pair_signrank);
    
    currXLabel = ['log(',currShownFitQualityName,'):Model I'];
    currYLabel = ['log(',currShownFitQualityName,'):Model II'];
    
    % show comparison
    figRowIndex = 1;
    figColIndex = fitQualityIndex;
    currLeftPos = leftPos(figColIndex);
    currBotPos = botPos(figRowIndex);
    currWidth = subFigWidth;
    currHeight = subFigHeight;
    subplot('position',[currLeftPos currBotPos currWidth currHeight])
    plot(currData_untuned,currData_tuned,'o', ...
        'MarkerEdgeColor','k','MarkerFaceColor','k')
    hold on;
    plot([currMin currMax],[currMin currMax],'k-.')
    text(textXPos,textYPos_coef,textString_coef,'FontSize',fontSize,'Color','k')
    text(textXPos,textYPos_signrank,textString_signrank,'FontSize',fontSize,'Color','k')
    xlim([currMin currMax])
    ylim([currMin currMax])
    xlabel(currXLabel,'FontSize',fontSize)
    ylabel(currYLabel,'FontSize',fontSize)
    axis square;
    
    set(gca,'FontSize',fontSize)
    box off;
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);