% this funtion aims to show results in Fig 2 for paper 'Cortical direction
% selectivity increases from the input to the output layers of visual
% cortex'
% created on 11-14-2024

clear all;
close all;
clc;

% get file info
filePath = mfilename('fullpath');
filePath = fileparts(filePath);
fileName = 'Fig3_Data.xlsx';

fullFileName = fullfile(filePath,fileName);

% pre-define some parameters
allLayerLabel = { ...
    '2/3', ...
    '4', ...
    '5', ...
    '6', ...
    'WM', ...
    };

layerID_output = [1 3];
layerID_input = [2 4];

groupLayerID = { ...
    layerID_output, ...
    layerID_input, ...
    };
groupLayerLabel = { ...
    'Output', ...
    'Input', ...
    };
currShownLayerNum = length(groupLayerID); % number of layers to be shown

normType = 'diff';
binNum = 13;

switch normType
    case {'diff','norm'}
        referenceValue_ranksum = 0;
    case 'ratio'
        referenceValue_ranksum = 1;
end

shownDataLabel_norm = 'Preferred Direction Difference';
absDiffFlag = 1;

currCircDiff = 180;

% parameters for showing results
figColNum = length(allLayerLabel)-1;
figRowNum = length(allLayerLabel)-1;

fontSize = 15;
lineWidth = 3;
markerSize = 5;

% get position for showing results
leftGap = 0.05; % gap from left edge
rightGap = 0.03; % gap from right edge
botGap = 0.08; % gap from bottom edge
topGap = 0.05; % gap from top edge

columnGap = 0.05; % gap between columns
rowGap = 0.05; % gap between rows

currWidth = 1-leftGap-rightGap-columnGap*(figColNum-1);
currHeight = 1-botGap-topGap-rowGap*(figRowNum-1);

subFigWidth = currWidth./figColNum;
subFigHeight = currHeight./figRowNum;

leftPos = linspace(leftGap,1-rightGap-subFigWidth,figColNum);
botPos = linspace(botGap,1-topGap-subFigHeight,figRowNum);
botPos = botPos(end:(-1):1);

% initialize name for saved figures
close all;

figureCount = 0;
figureName = [];
figureHandle = [];

% create a new figure
figureCount = figureCount+1;
figureName{figureCount} = 'Fig3';
figureHandle(figureCount) = figure(figureCount);

shownDataType = {'raw','thre'};

for dataTypeIndex = 1:length(shownDataType)
    currShownDataType = shownDataType{dataTypeIndex};
    
    switch currShownDataType
        case 'raw'
            % get data
            [allData,~,~] = xlsread(fullFileName,'Fig 3A');
        case 'thre'
            % get data
            [allData,~,~] = xlsread(fullFileName,'Fig 3B');
    end
    
    
    % allocate data
    pooledAnimalID = allData(:,1);
    pooledExpID = allData(:,2);
    pooledDepth = allData(:,3);
    pooledLayerID = allData(:,4);
    
    pooledData = allData(:,5);
    
    % get range for depth and data
    currDepthMin = 0;
    currDepthMax = 1;
    
    currDataMin = 0;
    currDataMax = 360;
    currDataRange = currDataMax-currDataMin;
    
    pooledData(pooledData < currDataMin) = currDataMin;
    pooledData(pooledData > currDataMax) = currDataMax;
    
    % get experiment ID for each site
    uniqueExpID = unique(pooledExpID);
    uniqueExpNum = length(uniqueExpID);
    
    % get reference data
    withReferenceDataFlag = 1;
    inputReferenceData = 0;
    
    % get color for each animal
    allUniqueAnimalNum = length(unique(pooledAnimalID));
    allAnimalColor = zeros(allUniqueAnimalNum,3);
    
    %% show relation across layers
    shownPairLayerIndex_reference = [1 2 1];
    shownPairLayerIndex_target = [1 2 2];
    shownPairLayerName = { ...
        'Within Output Layers', ....
        'Within Input Layers', ....
        'Across Layers', ....
        };
    
    for pairIndex = 1:length(shownPairLayerIndex_reference)
        referenceLayerIndex = shownPairLayerIndex_reference(pairIndex);
        targetLayerIndex = shownPairLayerIndex_target(pairIndex);
        currPairLayerName = shownPairLayerName{pairIndex};
        
        % get index for electrodes in reference layer
        currLayerID_reference = groupLayerID{referenceLayerIndex};
        currLayerName_reference = groupLayerLabel{referenceLayerIndex};
        currXLabel = [currLayerName_reference];
        
        currElecIndex_reference = [];
        for tempLayerIndex = 1:length(currLayerID_reference)
            tempLayerID = currLayerID_reference(tempLayerIndex);
            tempElecIndex_reference = find(pooledLayerID == tempLayerID);
            currElecIndex_reference = [currElecIndex_reference;tempElecIndex_reference(:)];
        end
        
        % get index for electrodes in target layer
        currLayerID_target = groupLayerID{targetLayerIndex};
        currLayerName_target = groupLayerLabel{targetLayerIndex};
        currYLabel = [currLayerName_target];
        
        currElecIndex_target = [];
        for tempLayerIndex = 1:length(currLayerID_target)
            tempLayerID = currLayerID_target(tempLayerIndex);
            tempElecIndex_target = find(pooledLayerID == tempLayerID);
            currElecIndex_target = [currElecIndex_target;tempElecIndex_target(:)];
        end
        
        %% get pair of data belonging to L4 and L23 or belonging to input layer and output layer
        % initialize data for L4/input layer and L23/output layer
        pooledData_reference_median = [];
        pooledData_target_median = [];
        
        pooledData_reference_ste = [];
        pooledData_target_ste = [];
        
        pooledAnimalID_pair = [];
        pooledExpID_pair = [];
        
        % get data for L4/input layer and L23/output layer
        if referenceLayerIndex ~= targetLayerIndex
            for elecIndex = 1:length(currElecIndex_reference)
                % get animal ID and exp ID for current electrode in L4/input layer
                tempElecIndex_reference = currElecIndex_reference(elecIndex);
                tempAnimalID = pooledAnimalID(tempElecIndex_reference);
                tempExpID = pooledExpID(tempElecIndex_reference);
                
                % get index for electrode in L23/output layer of the same exp
                tempElecIndex_target = find(pooledExpID == tempExpID);
                tempElecIndex_target = intersect(tempElecIndex_target,currElecIndex_target);
                
                if ~isempty(tempElecIndex_target)
                    % get data
                    tempData_reference = pooledData(tempElecIndex_reference);
                    tempData_target = pooledData(tempElecIndex_target);
                    
                    % pool data
                    pooledData_reference_median = [pooledData_reference_median(:);repmat(tempData_reference,length(tempElecIndex_target),1)];
                    pooledData_target_median = [pooledData_target_median(:);tempData_target(:)];
                    
                    pooledAnimalID_pair = [pooledAnimalID_pair(:);repmat(tempAnimalID,length(tempElecIndex_target),1)];
                    pooledExpID_pair = [pooledExpID_pair(:);repmat(tempExpID,length(tempElecIndex_target),1)];
                end
            end
        else
            for tempIndex_reference = 1:(length(currElecIndex_reference)-1)
                % get animal ID and exp ID for current electrode in L4/input layer
                tempElecIndex_reference = currElecIndex_reference(tempIndex_reference);
                tempAnimalID_reference = pooledAnimalID(tempElecIndex_reference);
                tempExpID_reference = pooledExpID(tempElecIndex_reference);
                
                for tempIndex_target = (tempIndex_reference+1):length(currElecIndex_target)
                    % get animal ID and exp ID for current electrode in L4/input layer
                    tempElecIndex_target = currElecIndex_target(tempIndex_target);
                    tempAnimalID_target = pooledAnimalID(tempElecIndex_target);
                    tempExpID_target = pooledExpID(tempElecIndex_target);
                    
                    if tempExpID_reference == tempExpID_target
                        % get data
                        tempData_reference = pooledData(tempElecIndex_reference);
                        tempData_target = pooledData(tempElecIndex_target);
                        
                        % pool data
                        pooledData_reference_median = [pooledData_reference_median(:);tempData_reference];
                        pooledData_target_median = [pooledData_target_median(:);tempData_target];
                        
                        pooledAnimalID_pair = [pooledAnimalID_pair(:);tempAnimalID_reference];
                        pooledExpID_pair = [pooledExpID_pair(:);tempExpID_reference];
                    end
                end
            end
        end
        
        pooledData_reference_ste = zeros(size(pooledData_reference_median));
        pooledData_target_ste = zeros(size(pooledData_target_median));
        
        if isempty(pooledData_reference_median)
            pooledData_reference_median = currDataMin;
            pooledData_target_median = currDataMin;
            
            pooledData_reference_ste = 0;
            pooledData_target_ste = 0;
        end
        
        % get statistics
        [currCoef_pair_coef,currPVal_pair_coef] = corr(pooledData_reference_median,pooledData_target_median,'type','Spearman');
        
        currPVal_pair_signrank = signrank(pooledData_reference_median,pooledData_target_median);
        
        % do linear fitting
        fitXX_data = [currDataMin,currDataMax];
        
        currFitCoef = polyfit(pooledData_reference_median,pooledData_target_median,1);
        currFitYY = currFitCoef*[fitXX_data;1,1];
        
        %% show distribution of difference
        % get color show indicating layer
        if referenceLayerIndex == targetLayerIndex
            switch currLayerName_reference
                case {'L2/3','L5','Output'}
                    currColor_layer = 'b';
                case {'L4','L6','Input'}
                    currColor_layer = 'r';
            end
        else
            currColor_layer = 'k';
        end
        
        % get differences between different layers
        switch normType
            case 'diff'
                if referenceLayerIndex == targetLayerIndex || ... % difference within the same layer
                        absDiffFlag == 1 % calculate absolute difference explicitly
                    currData_diff = abs(pooledData_target_median-pooledData_reference_median);
                else
                    currData_diff = pooledData_target_median-pooledData_reference_median;
                end
            case 'ratio'
                currData_diff = log2(pooledData_target_median./pooledData_reference_median);
            case 'norm'
                if referenceLayerIndex == targetLayerIndex || ... % difference within the same layer
                        absDiffFlag == 1 % calculate absolute difference explicitly
                    currData_diff = abs((pooledData_target_median-pooledData_reference_median)./pooledData_reference_median);
                else
                    currData_diff = (pooledData_target_median-pooledData_reference_median)./pooledData_reference_median;
                end
                %                             currData_diff = pooledData_reference_median./pooledData_target_median; % modified on 2024-01-24
        end
        
        if exist('currCircDiff','var') % modify difference for circular variable
            currData_diff(currData_diff > currCircDiff) = 2*currCircDiff-currData_diff(currData_diff > currCircDiff);
        end
        
        switch normType
            case {'ratio','norm'}
                currData_diff(currData_diff > maxValue_norm) = maxValue_norm;
                currData_diff(currData_diff < -maxValue_norm) = -maxValue_norm;
        end
        
        currPVal_diff_ranksum = ranksum(currData_diff,referenceValue_ranksum);
        
        % get range and bin for histogram
        if exist('currCircDiff','var') % modify difference for circular variable
            currMax_diff = currCircDiff;
        else
            currMax_diff = max(abs(currData_diff));
            %                     currMax_diff = currMax_diff*(1+0.05*sign(currMax_diff));
        end
        if currMax_diff == 0
            currMax_diff = 1e-6;
        end
        
        if referenceLayerIndex == targetLayerIndex || ... % difference within the same layer
                absDiffFlag == 1 % calculate absolute difference explicitly
            currMin_diff = 0;
        else
            currMin_diff = -currMax_diff;
        end
        
        currEdge_diff = linspace(currMin_diff,currMax_diff,binNum);
        
        currEdgeDiff_diff = (currEdge_diff(2)-currEdge_diff(1))/2;
        currShownEdge_diff = currEdge_diff+currEdgeDiff_diff;
        currShownEdge_diff = currShownEdge_diff(1:(end-1));
        
        % get histogram
        currHist_diff = histcounts(currData_diff,currEdge_diff);
        currHist_diff = currHist_diff./sum(currHist_diff);
        
        % get cumulative distribution
        currCumDistribution_diff = cumsum(currHist_diff);
        
        % get statistics
        currMedian_diff = median(currData_diff);
        currMean_diff = mean(currData_diff);
        currStd_diff = std(currData_diff);
        currSte_diff = currStd_diff./sqrt(length(currData_diff));
        
        % range for showing results
        currXMin = currEdge_diff(1)-currEdgeDiff_diff;
        currXMax = currEdge_diff(end)+currEdgeDiff_diff*2;
        currXRange = currXMax-currXMin;
        
        currHistMin = 0;
        currHistMax = max(currHist_diff(:));
        currHistRange = currHistMax-currHistMin;
        
        errorbarYPos = currHistMin+currHistRange*1.05;
        
        currYMin = currHistMin;
        currYMax = currHistMin+currHistRange*1.1;
        currYRange = currYMax-currYMin;
        
        textXPos = currXMin+currXRange*0.4;
        textYPos_signrank = currYMin+currYRange*0.9;
        
        currXLabel_diff = shownDataLabel_norm;
        
        % show histogram
        figRowIndex = (dataTypeIndex-1)*2+1;
        figColIndex = pairIndex;
        currLeftPos = leftPos(figColIndex);
        currBotPos = botPos(figRowIndex);
        currWidth = subFigWidth;
        currHeight = subFigHeight;
        subplot('position',[currLeftPos currBotPos currWidth currHeight])
        currBarHandle = bar(currShownEdge_diff,currHist_diff(:));
        set(currBarHandle,'EdgeColor',currColor_layer,'FaceColor',currColor_layer)
        hold on;
        errorbar(currMedian_diff,errorbarYPos,currSte_diff, ...
            '-','horizontal','Color',currColor_layer)
        plot(currMedian_diff,errorbarYPos,'o', ...
            'MarkerEdgeColor',currColor_layer,'MarkerFaceColor',currColor_layer)
        plot([0 0],[currYMin currYMax],'k-.')
        text(textXPos,textYPos_signrank,sprintf('N=%d pairs', ...
            length(pooledData_target_median)),'FontSize',fontSize,'Color','k')
        xlim([currXMin currXMax])
        ylim([currYMin currYMax])
        
        xlabel(currXLabel_diff,'FontSize',fontSize)
        ylabel('Proportion','FontSize',fontSize)
        title(currPairLayerName,'FontSize',fontSize,'Color',currColor_layer)
        axis square;
        
        set(gca,'FontSize',fontSize)
        box off;
    end
end

%% save figures
% file path for saving results
currSavedFilePath = [filePath,'\Fig'];
if ~exist(currSavedFilePath,'dir')
    mkdir(currSavedFilePath);
end

% save results
deleteOldResultFlag = 0; % don't delete previously saved figures
addFigIDFlag = 0; % add figure ID during naming
startFigID = 0;
saveEPSFlag = 1; % if(1) or not(0) save EPS
batchSaveFigure(currSavedFilePath,figureName,figureHandle,deleteOldResultFlag,addFigIDFlag,startFigID,saveEPSFlag);